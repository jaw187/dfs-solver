window["webpackHotUpdate"]("main",{

/***/ "./solver/queue.js":
/*!*************************!*\
  !*** ./solver/queue.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _solver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./solver */ "./solver/solver.js");
/* harmony import */ var _solver__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_solver__WEBPACK_IMPORTED_MODULE_0__);

var queue = [];
var Queue = {
  register: function register(n, maxIterations, model, ownership, players, sport, site, type, stack, preventMmaFightersInSameFight) {
    queue.push(Object(_solver__WEBPACK_IMPORTED_MODULE_0__["solve"])(n, maxIterations, model, ownership, players, sport, site, type, stack, preventMmaFightersInSameFight));
  },
  go: function go() {
    var results = [];

    while (queue.length) {
      var top = queue.shift();
      var response = top.go();

      if (response.notFeasible || top.isDone()) {
        results.push({
          results: top.results,
          stack: top.stack
        });
        continue;
      }

      queue.push(top);
    }

    return results;
  }
};
/* harmony default export */ __webpack_exports__["default"] = (Queue);

/***/ })

})
//# sourceMappingURL=main.438c372ecf51e0c56fab.hot-update.js.map