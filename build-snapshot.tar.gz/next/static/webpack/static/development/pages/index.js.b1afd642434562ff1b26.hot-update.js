webpackHotUpdate("static/development/pages/index.js",{

/***/ "./solver/solve.worker.js":
/*!********************************!*\
  !*** ./solver/solve.worker.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function () {
  return new Worker("/_next/" + "static/438c372ecf51e0c56fab.worker.js");
};

/***/ })

})
//# sourceMappingURL=index.js.b1afd642434562ff1b26.hot-update.js.map