webpackHotUpdate("static/development/pages/index.js",{

/***/ "./components/stackbuilder.js":
/*!************************************!*\
  !*** ./components/stackbuilder.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./card */ "./components/card.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _stacks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stacks */ "./components/stacks.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils */ "./components/utils.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_utils__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/index.js");
/* harmony import */ var _material_ui_core_InputLabel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/InputLabel */ "./node_modules/@material-ui/core/esm/InputLabel/index.js");
/* harmony import */ var _material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/MenuItem */ "./node_modules/@material-ui/core/esm/MenuItem/index.js");
/* harmony import */ var _material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/FormControl */ "./node_modules/@material-ui/core/esm/FormControl/index.js");
/* harmony import */ var _material_ui_core_Select__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/Select */ "./node_modules/@material-ui/core/esm/Select/index.js");
var _jsxFileName = "/Users/jwesto1/Code/jaw187/dfs-solver/components/stackbuilder.js";
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;











var getState = function getState() {
  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"])();

  var _useSelector = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state;
  }, react_redux__WEBPACK_IMPORTED_MODULE_2__["shallowEqual"]),
      pool = _useSelector.pool,
      stack = _useSelector.stack,
      slates = _useSelector.slates,
      selectedSlate = _useSelector.selectedSlate,
      view = _useSelector.view;

  var clearStack = function clearStack() {
    return dispatch({
      type: "CLEAR_STACK"
    });
  };

  var addStack = function addStack() {
    return dispatch({
      type: "ADD_STACK",
      payload: stack
    });
  };

  var removeStack = function removeStack(i) {
    return dispatch({
      type: "REMOVE_STACK",
      payload: i
    });
  };

  var addPlayerToStack = function addPlayerToStack(player) {
    return dispatch({
      type: "ADD_PLAYER_TO_STACK",
      payload: player
    });
  };

  var removePlayerFromStack = function removePlayerFromStack(player) {
    return dispatch({
      type: "REMOVE_PLAYER_FROM_STACK",
      payload: player
    });
  };

  return {
    pool: pool,
    stack: stack,
    slate: slates[selectedSlate],
    clearStack: clearStack,
    addStack: addStack,
    removeStack: removeStack,
    addPlayerToStack: addPlayerToStack,
    removePlayerFromStack: removePlayerFromStack,
    view: view
  };
};

var StackBuilder = function StackBuilder() {
  var _getState = getState(),
      pool = _getState.pool,
      stack = _getState.stack,
      slate = _getState.slate,
      clearStack = _getState.clearStack,
      addStack = _getState.addStack,
      addPlayerToStack = _getState.addPlayerToStack,
      removePlayerFromStack = _getState.removePlayerFromStack,
      view = _getState.view;

  if (view !== 'stackbuilder') {
    return null;
  }

  if (!pool.length) {
    return __jsx("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 54
      },
      __self: this
    }, "Pick players for pool first.");
  }

  var togglePlayer = function togglePlayer(player) {
    return function () {
      var inStack = stack && !!stack.find(function (stackPlayer) {
        return player.playerId === stackPlayer.playerId;
      });

      if (inStack) {
        return removePlayerFromStack(player);
      }

      addPlayerToStack(player);
    };
  };

  var checkboxes = [];

  var clear = function clear() {
    checkboxes.forEach(function (checkbox) {
      checkbox.current.checked = false;
    });
    clearStack();
  };

  var add = function add() {
    Object(_utils__WEBPACK_IMPORTED_MODULE_4__["log"])('stack add');
    addStack();
    clear();
  };

  var componentContainer = {
    display: 'flex',
    flexDirection: 'row',
    padding: 16
  };
  var cardContainer = {
    display: 'flex',
    flexDirection: 'row'
  };
  var poolPlayer = {
    paddingLeft: 4,
    verticalAlign: 'middle',
    fontSize: 12
  };
  var playerContainer = {
    paddingBottom: 4,
    verticalAlign: 'middle'
  };
  var stackPlayer = {
    paddingLeft: 16,
    paddingBottom: 4
  };
  var stackButtons = {
    display: 'flex',
    flexDirection: 'row',
    marginTop: 16
  };
  var stackButton = {
    marginRight: 16
  };
  return __jsx("div", {
    style: componentContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 122
    },
    __self: this
  }, __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 123
    },
    __self: this
  }, __jsx("h2", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 124
    },
    __self: this
  }, "Stack Builder"), __jsx("div", {
    style: cardContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 125
    },
    __self: this
  }, __jsx(_card__WEBPACK_IMPORTED_MODULE_1__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 126
    },
    __self: this
  }, __jsx("h3", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 127
    },
    __self: this
  }, "Filters"), __jsx(_material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_8__["default"], {
    style: {
      minWidth: 120
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 128
    },
    __self: this
  }, __jsx(_material_ui_core_InputLabel__WEBPACK_IMPORTED_MODULE_6__["default"], {
    id: "select-label",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 129
    },
    __self: this
  }, "Games"), __jsx(_material_ui_core_Select__WEBPACK_IMPORTED_MODULE_9__["default"], {
    labelId: "select-label",
    onChange: selectPoolGame,
    value: poolGame,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 130
    },
    __self: this
  }, slate.competitions && slate.competitions.map(function (competition, i) {
    return __jsx(_material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_7__["default"], {
      value: competition.competitionId,
      key: i,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 133
      },
      __self: this
    }, competition.name);
  }), __jsx(_material_ui_core_MenuItem__WEBPACK_IMPORTED_MODULE_7__["default"], {
    value: null,
    selected: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 136
    },
    __self: this
  }, "ALL"))))), __jsx("div", {
    style: cardContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 141
    },
    __self: this
  }, __jsx(_card__WEBPACK_IMPORTED_MODULE_1__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 142
    },
    __self: this
  }, __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 143
    },
    __self: this
  }, __jsx("div", {
    style: {
      display: "flex",
      flexDirection: "row"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 144
    },
    __self: this
  }, __jsx("div", {
    style: {
      minWidth: 240
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 148
    },
    __self: this
  }, __jsx("h3", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 149
    },
    __self: this
  }, "Players"), pool && pool.map(function (player, i) {
    var ref = react__WEBPACK_IMPORTED_MODULE_0___default.a.createRef();
    checkboxes.push(ref);
    return __jsx("div", {
      style: playerContainer,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 156
      },
      __self: this
    }, __jsx("label", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 157
      },
      __self: this
    }, __jsx("input", {
      ref: ref,
      type: "checkbox",
      onClick: togglePlayer(player),
      key: i,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 158
      },
      __self: this
    }), __jsx("span", {
      style: poolPlayer,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 158
      },
      __self: this
    }, player.displayName, " - $", player.salary)));
  })), __jsx("div", {
    style: {
      paddingLeft: 16,
      minWidth: 240
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 165
    },
    __self: this
  }, __jsx("h3", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 166
    },
    __self: this
  }, "Stack"), stack && stack.map(function (player, i) {
    return __jsx("div", {
      key: i,
      style: stackPlayer,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 169
      },
      __self: this
    }, player.displayName);
  }), stack && stack.length > 1 && __jsx("div", {
    style: stackButtons,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 174
    },
    __self: this
  }, __jsx("div", {
    style: stackButton,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 175
    },
    __self: this
  }, __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_5__["default"], {
    onClick: add,
    variant: "contained",
    color: "primary",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 176
    },
    __self: this
  }, "Add")), __jsx("div", {
    style: stackButton,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 178
    },
    __self: this
  }, __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_5__["default"], {
    onClick: clear,
    variant: "contained",
    color: "secondary",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 179
    },
    __self: this
  }, "Clear"))))))))), __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 190
    },
    __self: this
  }, __jsx(_stacks__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 191
    },
    __self: this
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (StackBuilder);

/***/ })

})
//# sourceMappingURL=index.js.fd86ba88a228280bb047.hot-update.js.map