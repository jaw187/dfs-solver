webpackHotUpdate("static/development/pages/index.js",{

/***/ "./components/lineups.js":
/*!*******************************!*\
  !*** ./components/lineups.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./card */ "./components/card.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _solver_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../solver/index */ "./solver/index.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils */ "./components/utils.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_utils__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _generator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./generator */ "./components/generator.js");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/index.js");

var _jsxFileName = "/Users/jwesto1/Code/jaw187/dfs-solver/components/lineups.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;






var solve = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].solve,
    Models = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].Models,
    players = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].players;

var getState = function getState() {
  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useDispatch"])();
  var slates = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.slates;
  }, react_redux__WEBPACK_IMPORTED_MODULE_3__["shallowEqual"]);
  var selectedSlate = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.selectedSlate;
  });
  var results = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.results;
  });
  var view = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.view;
  });
  var stacksUsed = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.stacksUsed;
  });

  var removeLineup = function removeLineup(i, j) {
    dispatch({
      type: 'REMOVE_RESULT',
      payload: {
        i: i,
        j: j
      }
    });
  };

  var clearLineups = function clearLineups() {
    dispatch({
      type: 'CLEAR_LINEUPS'
    });
  };

  return {
    slates: slates,
    selectedSlate: selectedSlate,
    results: results,
    view: view,
    removeLineup: removeLineup,
    stacksUsed: stacksUsed,
    clearLineups: clearLineups
  };
};

var Lineups = function Lineups() {
  var _getState = getState(),
      slates = _getState.slates,
      selectedSlate = _getState.selectedSlate,
      results = _getState.results,
      view = _getState.view,
      removeLineup = _getState.removeLineup,
      stacksUsed = _getState.stacksUsed,
      clearLineups = _getState.clearLineups;

  if (view !== 'results') {
    return null;
  } // Reorganized results.  Breaking change.


  if (results.length && !(results[0].length >= 0)) {
    return 'Old state observed.  Clear session';
  }

  var slate = slates && slates[selectedSlate];
  var sport = slate.Sport.toLowerCase();
  var site = 'draftkings';
  var type = slate.GameType.Name.toLowerCase();
  var exporters = {
    nfl: {
      draftkings: {
        classic: function classic(result) {
          var _result$lineup = result.lineup,
              qb = _result$lineup.qb,
              rbs = _result$lineup.rbs,
              wrs = _result$lineup.wrs,
              te = _result$lineup.te,
              flex = _result$lineup.flex,
              dst = _result$lineup.dst;
          return "".concat(qb.id, ",").concat(rbs[0].id, ",").concat(rbs[1].id, ",").concat(wrs[0].id, ",").concat(wrs[1].id, ",").concat(wrs[2].id, ",").concat(te.id, ",").concat(flex.id, ",").concat(dst.id);
        }
      }
    },
    golf: {
      draftkings: {
        classic: function classic(result) {
          var g = result.lineup.g;
          return "".concat(g[0].id, ",").concat(g[1].id, ",").concat(g[2].id, ",").concat(g[3].id, ",").concat(g[4].id, ",").concat(g[5].id);
        }
      }
    }
  };

  var generateLineupString = function generateLineupString(lineup) {
    exporters[sport][site][type];
    var ids = exporters[sport][site][type](lineup).split(',');
    ids.sort(function (a, b) {
      return a > b ? 1 : -1;
    });
    return ids.join('');
  };

  var playerCounts = {};
  var lineupStrings = [];
  results.forEach(function (stack) {
    stack.forEach(function (result) {
      var lineupString = generateLineupString(result);

      if (!lineupStrings.includes(lineupString)) {
        lineupStrings.push(lineupString);
        result.players.forEach(function (player) {
          if (!playerCounts[player]) {
            playerCounts[player] = 0;
          }

          ++playerCounts[player];
        });
      }
    });
  });

  var formatPlayer = function formatPlayer(lineupPlayer) {
    var player = slate.players.find(function (player) {
      return player.draftableId == lineupPlayer.id;
    });

    if (!player) {
      return lineupPlayer.id;
    }

    return "".concat(player.position, " - ").concat(player.displayName, " - $").concat(player.salary);
  };

  var headers = {
    nfl: {
      draftkings: {
        classic: "QB,RB,RB,WR,WR,WR,TE,FLEX,DST\n"
      }
    },
    golf: {
      draftkings: {
        classic: "G,G,G,G,G,G\n"
      }
    }
  };

  var exportToCSV = function exportToCSV() {
    Object(_utils__WEBPACK_IMPORTED_MODULE_5__["log"])('export linieups');
    var header = headers[sport][site][type];
    var lines = [];
    var exportedLines = [];
    results.forEach(function (result) {
      result.forEach(function (line) {
        var lineupString = generateLineupString(line);

        if (!exportedLines.includes(lineupString)) {
          lines.push(line);
          exportedLines.push(lineupString);
        }
      });
    });
    var csv = "data:text/csv;charset=utf-8," + header + lines.map(exporters[sport][site][type]).join('\n');
    var _window = window,
        encodeURI = _window.encodeURI;
    var downloadLink = document.createElement("a");
    downloadLink.href = encodeURI(csv);
    downloadLink.download = "".concat(selectedSlate, " - Lineups.csv");
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  var remove = function remove(i, j) {
    Object(_utils__WEBPACK_IMPORTED_MODULE_5__["log"])('remove lineup');
    return function () {
      return removeLineup(i, j);
    };
  };

  var containerStyle = {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingBottom: 32
  };
  var lineupStyle = {
    padding: 16,
    margin: 8,
    backgroundColor: "#f3f3f3",
    border: '1px solid #DDD',
    fontSize: 12,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center'
  };
  var cardContainer = {
    display: 'flex',
    flexDirection: 'row'
  };
  var componentContainer = {
    padding: 16
  };

  var ownership = _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(playerCounts).map(function (player) {
    return {
      player: formatPlayer({
        id: player
      }),
      count: playerCounts[player],
      percentage: (playerCounts[player] / lineupStrings.length * 100).toFixed(0)
    };
  });

  var ownershipPlayerStyle = {
    whiteSpace: 'nowrap'
  };
  var removeButtonStyle = {
    marginTop: 16
  };
  var lineupFormats = {
    nfl: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 213
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 214
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 215
              },
              __self: this
            }, formatPlayer(result.lineup.qb)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 216
              },
              __self: this
            }, formatPlayer(result.lineup.rbs[0])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 217
              },
              __self: this
            }, formatPlayer(result.lineup.rbs[1])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 218
              },
              __self: this
            }, formatPlayer(result.lineup.wrs[0])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 219
              },
              __self: this
            }, formatPlayer(result.lineup.wrs[1])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 220
              },
              __self: this
            }, formatPlayer(result.lineup.wrs[2])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 221
              },
              __self: this
            }, formatPlayer(result.lineup.te)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 222
              },
              __self: this
            }, formatPlayer(result.lineup.flex)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 223
              },
              __self: this
            }, formatPlayer(result.lineup.dst))), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 225
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    },
    golf: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 235
              },
              __self: this
            }, __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 236
              },
              __self: this
            }, "Remove"), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 237
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 238
              },
              __self: this
            }, formatPlayer(result.lineup.g[0])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 239
              },
              __self: this
            }, formatPlayer(result.lineup.g[1])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 240
              },
              __self: this
            }, formatPlayer(result.lineup.g[2])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 241
              },
              __self: this
            }, formatPlayer(result.lineup.g[3])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 242
              },
              __self: this
            }, formatPlayer(result.lineup.g[4])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 243
              },
              __self: this
            }, formatPlayer(result.lineup.g[5]))));
          };
        }
      }
    }
  };
  var removeAllButtonStyle = {
    marginLeft: 24
  };

  var displayStack = function displayStack(stack, i) {
    console.log('watttttt', stack);
    return __jsx("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 259
      },
      __self: this
    }, __jsx("h4", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 260
      },
      __self: this
    }, stack.map(function (player) {
      return player.displayName;
    }).join(' - ')), __jsx("div", {
      style: containerStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 261
      },
      __self: this
    }, results[i] && results[i].map(lineupFormats[sport][site][type](i))));
  };

  return __jsx("div", {
    style: componentContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 271
    },
    __self: this
  }, __jsx("h2", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 272
    },
    __self: this
  }, "Lineups"), __jsx("div", {
    style: cardContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 273
    },
    __self: this
  }, __jsx(_generator__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 274
    },
    __self: this
  })), results && results.length > 0 && __jsx("div", {
    style: cardContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 277
    },
    __self: this
  }, __jsx(_card__WEBPACK_IMPORTED_MODULE_2__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 278
    },
    __self: this
  }, __jsx("h3", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 279
    },
    __self: this
  }, "Ownership"), !!ownership.length && __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 282
    },
    __self: this
  }, ownership.map(function (data) {
    return __jsx("div", {
      style: ownershipPlayerStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 285
      },
      __self: this
    }, data.player, " - ", data.count, " - ", data.percentage, "%");
  }))), __jsx(_card__WEBPACK_IMPORTED_MODULE_2__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 294
    },
    __self: this
  }, !!results.length && __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 297
    },
    __self: this
  }, __jsx("h3", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 298
    },
    __self: this
  }, "Your Lineups"), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
    onClick: exportToCSV,
    variant: "contained",
    color: "primary",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 299
    },
    __self: this
  }, "Export"), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
    onClick: clearLineups,
    variant: "contained",
    color: "secondary",
    style: removeAllButtonStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 300
    },
    __self: this
  }, "Remove All"), __jsx("h4", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 301
    },
    __self: this
  }, lineupStrings.length, " unique results"), stacksUsed && stacksUsed.map(displayStack)))));
};

/* harmony default export */ __webpack_exports__["default"] = (Lineups);

/***/ })

})
//# sourceMappingURL=index.js.adee9c899d4dc53e8c0d.hot-update.js.map