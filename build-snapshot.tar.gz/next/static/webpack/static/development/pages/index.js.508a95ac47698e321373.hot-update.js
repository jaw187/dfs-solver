webpackHotUpdate("static/development/pages/index.js",{

/***/ "./components/lineups.js":
/*!*******************************!*\
  !*** ./components/lineups.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./card */ "./components/card.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _solver_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../solver/index */ "./solver/index.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils */ "./components/utils.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_utils__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _generator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./generator */ "./components/generator.js");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/index.js");

var _jsxFileName = "/Users/jwesto1/Code/jaw187/dfs-solver/components/lineups.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;






var solve = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].solve,
    Models = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].Models,
    players = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].players;

var getState = function getState() {
  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useDispatch"])();
  var slates = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.slates;
  }, react_redux__WEBPACK_IMPORTED_MODULE_3__["shallowEqual"]);
  var selectedSlate = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.selectedSlate;
  });
  var results = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.results;
  });
  var view = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.view;
  });
  var stacksUsed = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.stacksUsed;
  });
  var projection = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.projection;
  });

  var removeLineup = function removeLineup(i, j) {
    dispatch({
      type: 'REMOVE_RESULT',
      payload: {
        i: i,
        j: j
      }
    });
  };

  var clearLineups = function clearLineups() {
    dispatch({
      type: 'CLEAR_LINEUPS'
    });
  };

  return {
    slates: slates,
    selectedSlate: selectedSlate,
    results: results,
    view: view,
    removeLineup: removeLineup,
    stacksUsed: stacksUsed,
    clearLineups: clearLineups,
    projection: projection
  };
};

var Lineups = function Lineups() {
  var _getState = getState(),
      slates = _getState.slates,
      selectedSlate = _getState.selectedSlate,
      results = _getState.results,
      view = _getState.view,
      removeLineup = _getState.removeLineup,
      stacksUsed = _getState.stacksUsed,
      clearLineups = _getState.clearLineups,
      projection = _getState.projection;

  if (view !== 'results') {
    return null;
  } // Reorganized results.  Breaking change.


  if (results.length && !results[0].stack) {
    return 'Old state observed.  Clear session';
  }

  var slate = slates && slates[selectedSlate];
  var sport = slate && slate.Sport.toLowerCase();
  var site = 'draftkings';
  var type = slate && slate.GameType.Name.toLowerCase();
  var exporters = {
    nfl: {
      draftkings: {
        classic: function classic(result) {
          var _result$lineup = result.lineup,
              qb = _result$lineup.qb,
              rbs = _result$lineup.rbs,
              wrs = _result$lineup.wrs,
              te = _result$lineup.te,
              flex = _result$lineup.flex,
              dst = _result$lineup.dst;
          return "".concat(qb.id, ",").concat(rbs[0].id, ",").concat(rbs[1].id, ",").concat(wrs[0].id, ",").concat(wrs[1].id, ",").concat(wrs[2].id, ",").concat(te.id, ",").concat(flex.id, ",").concat(dst.id);
        }
      }
    },
    golf: {
      draftkings: {
        classic: function classic(result) {
          var g = result.lineup.g;
          return "".concat(g[0].id, ",").concat(g[1].id, ",").concat(g[2].id, ",").concat(g[3].id, ",").concat(g[4].id, ",").concat(g[5].id);
        }
      }
    },
    mma: {
      draftkings: {
        classic: function classic(result) {
          var f = result.lineup.f;
          return "".concat(f[0].id, ",").concat(f[1].id, ",").concat(f[2].id, ",").concat(f[3].id, ",").concat(f[4].id, ",").concat(f[5].id);
        }
      }
    },
    nba: {
      draftkings: {
        classic: function classic(result) {
          var _result$lineup2 = result.lineup,
              pg = _result$lineup2.pg,
              sg = _result$lineup2.sg,
              sf = _result$lineup2.sf,
              pf = _result$lineup2.pf,
              c = _result$lineup2.c,
              g = _result$lineup2.g,
              f = _result$lineup2.f,
              flex = _result$lineup2.flex;
          return "".concat(pg.id, ",").concat(sg.id, ",").concat(sf.id, ",").concat(pf.id, ",").concat(c.id, ",").concat(g.id, ",").concat(f.id, ",").concat(flex.id);
        }
      }
    },
    xfl: {
      draftkings: {
        classic: function classic(result) {
          var _result$lineup3 = result.lineup,
              qb = _result$lineup3.qb,
              rb = _result$lineup3.rb,
              wrs = _result$lineup3.wrs,
              flexes = _result$lineup3.flexes,
              dst = _result$lineup3.dst;
          return "".concat(qb.id, ",").concat(rb.id, ",").concat(wrs[0].id, ",").concat(wrs[1].id, ",").concat(flexes[0].id, ",").concat(flexes[1].id, ",").concat(dst.id);
        }
      }
    }
  };

  var generateLineupString = function generateLineupString(lineup) {
    var ids = exporters[sport][site][type](lineup).split(',');
    ids.sort(function (a, b) {
      return a > b ? 1 : -1;
    });
    return ids.join('');
  };

  var playerCounts = {};
  console.log('wattttt', results);
  var lineupStrings = [];
  results.forEach(function (stack) {
    stack.results.forEach(function (result) {
      var lineupString = generateLineupString(result);

      if (!lineupStrings.includes(lineupString)) {
        lineupStrings.push(lineupString);
        result.players.forEach(function (player) {
          if (!playerCounts[player]) {
            playerCounts[player] = 0;
          }

          ++playerCounts[player];
        });
      }
    });
  });
  var projectionStyle = {
    fontWeight: 700,
    textAlign: 'center'
  };
  var ownershipDataStyle = {
    textAlign: 'center'
  };

  var formatPlayer = function formatPlayer(_ref) {
    var id = _ref.id,
        data = _ref.data;
    var player = slate.players.find(function (player) {
      return player.draftableId == id;
    });

    if (!player) {
      return id;
    }

    var numberWithCommas = function numberWithCommas(x) {
      return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    };

    var playerProjection = Math.round(projection.filter(function (projectionPlayer) {
      return projectionPlayer.player === id;
    })[0].value);
    return __jsx("tr", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 157
      },
      __self: this
    }, __jsx("td", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 158
      },
      __self: this
    }, player.position), __jsx("td", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 159
      },
      __self: this
    }, player.displayName), __jsx("td", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 160
      },
      __self: this
    }, "$", numberWithCommas(player.salary)), __jsx("td", {
      style: projectionStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 161
      },
      __self: this
    }, playerProjection), data && __jsx("td", {
      style: ownershipDataStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 163
      },
      __self: this
    }, data.count), data && __jsx("td", {
      style: ownershipDataStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 166
      },
      __self: this
    }, data.percentage, "%"));
  };

  var headers = {
    nfl: {
      draftkings: {
        classic: "QB,RB,RB,WR,WR,WR,TE,FLEX,DST\n"
      }
    },
    golf: {
      draftkings: {
        classic: "G,G,G,G,G,G\n"
      }
    },
    mma: {
      draftkings: {
        classic: "F,F,F,F,F,F\n"
      }
    },
    nba: {
      draftkings: {
        classic: "PG,SG,SF,PF,C,G,F,UTIL\n"
      }
    },
    xfl: {
      draftkings: {
        classic: "QB,RB,WR,WR,FLEX,FLEX,DST\n"
      }
    }
  };

  var exportToCSV = function exportToCSV() {
    Object(_utils__WEBPACK_IMPORTED_MODULE_5__["log"])('export linieups');
    var header = headers[sport][site][type];
    var lines = [];
    var exportedLines = [];
    results.forEach(function (stack) {
      stack.results.forEach(function (line) {
        var lineupString = generateLineupString(line);

        if (!exportedLines.includes(lineupString)) {
          lines.push(line);
          exportedLines.push(lineupString);
        }
      });
    });
    var csv = "data:text/csv;charset=utf-8," + header + lines.map(exporters[sport][site][type]).join('\n');
    var _window = window,
        encodeURI = _window.encodeURI;
    var downloadLink = document.createElement("a");
    downloadLink.href = encodeURI(csv);
    downloadLink.download = "".concat(selectedSlate, " - Lineups.csv");
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  var remove = function remove(i, j) {
    Object(_utils__WEBPACK_IMPORTED_MODULE_5__["log"])('remove lineup');
    return function () {
      return removeLineup(i, j);
    };
  };

  var containerStyle = {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingBottom: 32
  };
  var lineupStyle = {
    padding: 16,
    margin: 8,
    backgroundColor: "#f3f3f3",
    border: '1px solid #DDD',
    fontSize: 12,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center'
  };
  var cardContainer = {
    display: 'flex',
    flexDirection: 'row'
  };
  var componentContainer = {
    padding: 16
  };

  var ownership = _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(playerCounts).map(function (player) {
    var data = {
      count: playerCounts[player],
      percentage: (playerCounts[player] / lineupStrings.length * 100).toFixed(0)
    };
    return formatPlayer({
      id: player,
      data: data
    });
  });

  var ownershipPlayerStyle = {
    whiteSpace: 'nowrap'
  };
  var removeButtonStyle = {
    marginTop: 16
  };
  var lineupTotalStyle = {
    paddingTop: 8,
    display: 'flex',
    fontSize: 18,
    justifyContent: 'center',
    fontWeight: 700
  };
  var tableHeaderStyle = {
    textAlign: 'left'
  };
  var lineupFormats = {
    nfl: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 293
              },
              __self: this
            }, __jsx("table", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 294
              },
              __self: this
            }, __jsx("thead", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 295
              },
              __self: this
            }, __jsx("tr", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 296
              },
              __self: this
            }, __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 297
              },
              __self: this
            }, "Pos"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 298
              },
              __self: this
            }, "Player"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 299
              },
              __self: this
            }, "Salary"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 300
              },
              __self: this
            }, "Proj"))), formatPlayer(result.lineup.qb), formatPlayer(result.lineup.rbs[0]), formatPlayer(result.lineup.rbs[1]), formatPlayer(result.lineup.wrs[0]), formatPlayer(result.lineup.wrs[1]), formatPlayer(result.lineup.wrs[2]), formatPlayer(result.lineup.te), formatPlayer(result.lineup.flex), formatPlayer(result.lineup.dst)), __jsx("div", {
              style: lineupTotalStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 313
              },
              __self: this
            }, Math.round(result.points)), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 314
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    },
    golf: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 324
              },
              __self: this
            }, __jsx("table", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 325
              },
              __self: this
            }, __jsx("thead", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 326
              },
              __self: this
            }, __jsx("tr", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 327
              },
              __self: this
            }, __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 328
              },
              __self: this
            }, "Pos"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 329
              },
              __self: this
            }, "Player"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 330
              },
              __self: this
            }, "Salary"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 331
              },
              __self: this
            }, "Proj"))), formatPlayer(result.lineup.g[0]), formatPlayer(result.lineup.g[1]), formatPlayer(result.lineup.g[2]), formatPlayer(result.lineup.g[3]), formatPlayer(result.lineup.g[4]), formatPlayer(result.lineup.g[5])), __jsx("div", {
              style: lineupTotalStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 341
              },
              __self: this
            }, Math.round(result.points)), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 342
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    },
    mma: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 352
              },
              __self: this
            }, __jsx("table", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 353
              },
              __self: this
            }, __jsx("thead", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 354
              },
              __self: this
            }, __jsx("tr", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 355
              },
              __self: this
            }, __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 356
              },
              __self: this
            }, "Pos"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 357
              },
              __self: this
            }, "Player"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 358
              },
              __self: this
            }, "Salary"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 359
              },
              __self: this
            }, "Proj"))), formatPlayer(result.lineup.f[0]), formatPlayer(result.lineup.f[1]), formatPlayer(result.lineup.f[2]), formatPlayer(result.lineup.f[3]), formatPlayer(result.lineup.f[4]), formatPlayer(result.lineup.f[5])), __jsx("div", {
              style: lineupTotalStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 369
              },
              __self: this
            }, Math.round(result.points)), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 370
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    },
    nba: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 380
              },
              __self: this
            }, __jsx("table", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 381
              },
              __self: this
            }, __jsx("thead", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 382
              },
              __self: this
            }, __jsx("tr", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 383
              },
              __self: this
            }, __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 384
              },
              __self: this
            }, "Pos"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 385
              },
              __self: this
            }, "Player"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 386
              },
              __self: this
            }, "Salary"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 387
              },
              __self: this
            }, "Proj"))), formatPlayer(result.lineup.pg), formatPlayer(result.lineup.sg), formatPlayer(result.lineup.sf), formatPlayer(result.lineup.pf), formatPlayer(result.lineup.c), formatPlayer(result.lineup.g), formatPlayer(result.lineup.f), formatPlayer(result.lineup.flex)), __jsx("div", {
              style: lineupTotalStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 399
              },
              __self: this
            }, Math.round(result.points)), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 400
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    },
    xfl: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 410
              },
              __self: this
            }, __jsx("table", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 411
              },
              __self: this
            }, __jsx("thead", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 412
              },
              __self: this
            }, __jsx("tr", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 413
              },
              __self: this
            }, __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 414
              },
              __self: this
            }, "Pos"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 415
              },
              __self: this
            }, "Player"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 416
              },
              __self: this
            }, "Salary"), __jsx("th", {
              style: tableHeaderStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 417
              },
              __self: this
            }, "Proj"))), formatPlayer(result.lineup.qb), formatPlayer(result.lineup.rb), formatPlayer(result.lineup.wrs[0]), formatPlayer(result.lineup.wrs[1]), formatPlayer(result.lineup.flexes[0]), formatPlayer(result.lineup.flexes[1]), formatPlayer(result.lineup.dst)), __jsx("div", {
              style: lineupTotalStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 428
              },
              __self: this
            }, Math.round(result.points)), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 429
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    }
  };
  var removeAllButtonStyle = {
    marginLeft: 24
  };
  var stackHeaderStyle = {
    marginBottom: 4
  };

  var displayStack = function displayStack(stack, i) {
    return __jsx("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 447
      },
      __self: this
    }, __jsx("h5", {
      style: stackHeaderStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 448
      },
      __self: this
    }, stack.stack.map(function (player) {
      return player.displayName;
    }).join(' - ')), __jsx("div", {
      style: containerStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 449
      },
      __self: this
    }, stack.results.map(lineupFormats[sport][site][type](i))));
  };

  return __jsx("div", {
    style: componentContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 459
    },
    __self: this
  }, __jsx("h2", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 460
    },
    __self: this
  }, "Lineups"), __jsx("div", {
    style: cardContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 461
    },
    __self: this
  }, __jsx(_generator__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 462
    },
    __self: this
  })), results && results.length > 0 && __jsx("div", {
    style: cardContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 465
    },
    __self: this
  }, __jsx(_card__WEBPACK_IMPORTED_MODULE_2__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 466
    },
    __self: this
  }, __jsx("h3", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 467
    },
    __self: this
  }, "Ownership"), !!ownership.length && __jsx("div", {
    style: ownershipPlayerStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 470
    },
    __self: this
  }, __jsx("table", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 471
    },
    __self: this
  }, __jsx("thead", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 472
    },
    __self: this
  }, __jsx("tr", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 473
    },
    __self: this
  }, __jsx("th", {
    style: tableHeaderStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 474
    },
    __self: this
  }, "Pos"), __jsx("th", {
    style: tableHeaderStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 475
    },
    __self: this
  }, "Player"), __jsx("th", {
    style: tableHeaderStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 476
    },
    __self: this
  }, "Salary"), __jsx("th", {
    style: tableHeaderStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 477
    },
    __self: this
  }, "Proj"), __jsx("th", {
    style: tableHeaderStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 478
    },
    __self: this
  }, "Count"), __jsx("th", {
    style: tableHeaderStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 479
    },
    __self: this
  }, "Own %"))), ownership.map(function (result) {
    return result;
  })))), __jsx(_card__WEBPACK_IMPORTED_MODULE_2__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 490
    },
    __self: this
  }, !!results.length && __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 493
    },
    __self: this
  }, __jsx("h3", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 494
    },
    __self: this
  }, "Your Lineups"), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
    onClick: exportToCSV,
    variant: "contained",
    color: "primary",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 495
    },
    __self: this
  }, "Export"), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
    onClick: clearLineups,
    variant: "contained",
    color: "secondary",
    style: removeAllButtonStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 496
    },
    __self: this
  }, "Remove All"), __jsx("h4", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 497
    },
    __self: this
  }, lineupStrings.length, " unique results"), results && results.map(displayStack)))));
};

/* harmony default export */ __webpack_exports__["default"] = (Lineups);

/***/ })

})
//# sourceMappingURL=index.js.508a95ac47698e321373.hot-update.js.map