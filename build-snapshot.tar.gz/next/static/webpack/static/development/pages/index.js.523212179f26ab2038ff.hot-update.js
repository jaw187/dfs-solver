webpackHotUpdate("static/development/pages/index.js",{

/***/ "./components/generator.js":
/*!*********************************!*\
  !*** ./components/generator.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./card */ "./components/card.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _solver_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../solver/index */ "./solver/index.js");
/* harmony import */ var lodash_clone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/clone */ "./node_modules/lodash/clone.js");
/* harmony import */ var lodash_clone__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_clone__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils */ "./components/utils.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_utils__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/index.js");
/* harmony import */ var _material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/CircularProgress */ "./node_modules/@material-ui/core/esm/CircularProgress/index.js");
/* harmony import */ var _material_ui_core_Checkbox__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/Checkbox */ "./node_modules/@material-ui/core/esm/Checkbox/index.js");
/* harmony import */ var _material_ui_core_FormControlLabel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/FormControlLabel */ "./node_modules/@material-ui/core/esm/FormControlLabel/index.js");
var _jsxFileName = "/Users/jwesto1/Code/jaw187/dfs-solver/components/generator.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;









var Models = _solver_index__WEBPACK_IMPORTED_MODULE_3__["default"].Models,
    players = _solver_index__WEBPACK_IMPORTED_MODULE_3__["default"].players,
    Worker = _solver_index__WEBPACK_IMPORTED_MODULE_3__["default"].Worker;

var getState = function getState() {
  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"])();
  var stacks = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.stacks;
  }, react_redux__WEBPACK_IMPORTED_MODULE_2__["shallowEqual"]);
  var stackCounts = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.stackCounts;
  }, react_redux__WEBPACK_IMPORTED_MODULE_2__["shallowEqual"]);
  var slates = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.slates;
  }, react_redux__WEBPACK_IMPORTED_MODULE_2__["shallowEqual"]);
  var selectedSlate = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.selectedSlate;
  });
  var projection = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.projection;
  });
  var results = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.results;
  });
  var pool = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.pool;
  });
  var view = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.view;
  });
  var generating = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(function (state) {
    return state.generating;
  });

  var addResults = function addResults(results) {
    dispatch({
      type: 'ADD_RESULT',
      payload: results
    });
  };

  var toggleGenerate = function toggleGenerate() {
    dispatch({
      type: 'GENERATE'
    });
  };

  return {
    stacks: stacks,
    stackCounts: stackCounts,
    slates: slates,
    selectedSlate: selectedSlate,
    projection: projection,
    addResults: addResults,
    results: results,
    pool: pool,
    view: view,
    toggleGenerate: toggleGenerate,
    generating: generating
  };
};

var Generator = function Generator() {
  var _getState = getState(),
      stacks = _getState.stacks,
      stackCounts = _getState.stackCounts,
      slates = _getState.slates,
      selectedSlate = _getState.selectedSlate,
      projection = _getState.projection,
      addResults = _getState.addResults,
      results = _getState.results,
      pool = _getState.pool,
      view = _getState.view,
      toggleGenerate = _getState.toggleGenerate,
      generating = _getState.generating;

  if (view !== 'generator' && view !== 'results') {
    return null;
  }

  if (!projection || stacks.length === 0) {
    var issues = [];

    if (stacks.length === 0) {
      issues.push(__jsx("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 76
        },
        __self: this
      }, "You need to create stacks first"));
    }

    if (!projection) {
      issues.push(__jsx("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 80
        },
        __self: this
      }, "You need to import projections first"));
    }

    return __jsx("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 84
      },
      __self: this
    }, issues.map(function (issue) {
      return __jsx("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 85
        },
        __self: this
      }, issue);
    }));
  }

  var slate = slates && slates[selectedSlate];
  var sport = slate.Sport.toLowerCase();
  var site = 'draftkings';
  var type = slate.GameType.Name.toLowerCase();
  var n = 0;
  stackCounts.forEach(function (count) {
    n = n + count;
  });

  var generate = function generate() {
    Object(_utils__WEBPACK_IMPORTED_MODULE_5__["log"])('generate');
    toggleGenerate();
    var playersForModel = players.convertPlayers(pool, projection, sport, site, type);
    var worker = new Worker();
    stacks.forEach(function (stack, i) {
      var stackPlayers = lodash_clone__WEBPACK_IMPORTED_MODULE_4___default()(playersForModel);
      var model = Models[sport][site][type](stackPlayers); // Force players in stack into lineup

      stack.forEach(function (player) {
        return model.constraints[player.draftableId] = {
          equal: 1
        };
      });
      var ownershipOptions = {
        players: stackPlayers,
        n: stackCounts[i],
        stack: stack
      };
      worker.postMessage({
        action: 'ownership',
        options: ownershipOptions
      });
      var enqueueOptions = {
        action: 'enqueue',
        n: stackCounts[i],
        maxIterations: 500,
        model: model,
        players: stackPlayers,
        sport: sport,
        site: site,
        type: type,
        stack: stack
      };
      worker.postMessage(enqueueOptions);
    });
    worker.postMessage({
      action: 'solve'
    });
    worker.addEventListener('message', function (event) {
      var results = event.data;
      toggleGenerate();
      Object(_utils__WEBPACK_IMPORTED_MODULE_5__["log"])("generated ".concat(results.length, " lineups"));

      if (results.length) {
        addResults(results);
      }
    });
  };

  var formatPlayer = function formatPlayer(draftableId) {
    var player = slate.players.find(function (player) {
      return player.draftableId == draftableId;
    });

    if (!player) {
      return draftableId;
    }

    return "".concat(player.position, " - ").concat(player.displayName, " - ").concat(player.salary);
  };

  var generateInfoStyle = {
    paddingLeft: 24
  };
  var generateContainerStyle = {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center'
  };
  var progressContainerStyle = {
    paddingLeft: 24
  };
  return __jsx(_card__WEBPACK_IMPORTED_MODULE_1__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 165
    },
    __self: this
  }, __jsx("div", {
    style: generateContainerStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 166
    },
    __self: this
  }, __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_6__["default"], {
    onClick: generate,
    variant: "contained",
    color: "primary",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 167
    },
    __self: this
  }, "Generate ".concat(n, " Lineups")), generating && __jsx("div", {
    style: progressContainerStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 170
    },
    __self: this
  }, __jsx(_material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 171
    },
    __self: this
  })), __jsx("div", {
    style: generateInfoStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 175
    },
    __self: this
  }, "Pool length: ".concat(pool.length)), __jsx("div", {
    style: generateInfoStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 178
    },
    __self: this
  }, "Stacks: ".concat(stacks.length))), sport === 'mma' && __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 184
    },
    __self: this
  }, __jsx(_material_ui_core_FormControlLabel__WEBPACK_IMPORTED_MODULE_9__["default"], {
    control: __jsx(_material_ui_core_Checkbox__WEBPACK_IMPORTED_MODULE_8__["default"], {
      value: "checkedB",
      color: "primary",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 187
      },
      __self: this
    }),
    label: "Prevent fighters in the same fight from being in the same lineup",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 185
    },
    __self: this
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Generator);

/***/ })

})
//# sourceMappingURL=index.js.523212179f26ab2038ff.hot-update.js.map