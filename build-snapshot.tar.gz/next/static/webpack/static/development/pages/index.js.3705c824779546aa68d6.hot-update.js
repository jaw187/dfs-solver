webpackHotUpdate("static/development/pages/index.js",{

/***/ "./store.js":
/*!******************!*\
  !*** ./store.js ***!
  \******************/
/*! exports provided: initializeStore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeStore", function() { return initializeStore; });
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-properties */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptors */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptors.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptor */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-symbols */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime-corejs2/helpers/esm/toConsumableArray.js");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! redux */ "./node_modules/redux/es/redux.js");
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! redux-devtools-extension */ "./node_modules/redux-devtools-extension/index.js");
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! redux-persist */ "./node_modules/redux-persist/es/index.js");
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! redux-persist/lib/storage */ "./node_modules/redux-persist/lib/storage/index.js");
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_11__);









function ownKeys(object, enumerableOnly) { var keys = _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5___default()(object); if (_babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default.a) { var symbols = _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default()(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default()(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_6__["default"])(target, key, source[key]); }); } else if (_babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default.a) { _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1___default()(target, _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default()(source)); } else { ownKeys(Object(source)).forEach(function (key) { _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, key, _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default()(source, key)); }); } } return target; }





var initialState = {
  slates: {},
  importErrors: [],
  stack: [],
  stacks: [],
  stackCounts: [],
  results: [],
  pool: [],
  view: 'slatepicker',
  showPoolTools: false,
  generating: false,
  stacksUsed: []
};

var reducer = function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;

  var _ref = arguments.length > 1 ? arguments[1] : undefined,
      type = _ref.type,
      payload = _ref.payload;

  var stackCounts = Object(_babel_runtime_corejs2_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_7__["default"])(state.stackCounts);

  var _ref2 = payload ? payload : {},
      i = _ref2.i,
      j = _ref2.j,
      n = _ref2.n;

  switch (type) {
    case 'SET_SLATES':
      return _objectSpread({}, state, {
        slates: _objectSpread({}, payload)
      });

    case 'SET_SELECTED_SLATE':
      return _objectSpread({}, state, {
        selectedSlate: payload
      });

    case 'CLEAR_IMPORT_ERRORS':
      return _objectSpread({}, state, {
        importErrors: []
      });

    case 'ADD_IMPORT_ERROR':
      return _objectSpread({}, state, {
        importErrors: state.importErrors.concat([payload])
      });

    case 'SET_RAW_PROJECTION':
      return _objectSpread({}, state, {
        rawProjection: payload
      });

    case 'SET_PROJECTION':
      return _objectSpread({}, state, {
        projection: payload
      });

    case 'CLEAR_STACK':
      return _objectSpread({}, state, {
        stack: []
      });

    case 'ADD_STACK':
      return _objectSpread({}, state, {
        stacks: state.stacks.concat([payload]),
        stackCounts: state.stackCounts.concat([0])
      });

    case 'REMOVE_STACK':
      return _objectSpread({}, state, {
        stacks: state.stacks.filter(function (stack, i) {
          return i !== payload;
        }),
        stackCounts: state.stackCounts.filter(function (n, i) {
          return i !== payload;
        })
      });

    case 'ADD_PLAYER_TO_STACK':
      return _objectSpread({}, state, {
        stack: state.stack.concat([payload])
      });

    case 'REMOVE_PLAYER_FROM_STACK':
      return _objectSpread({}, state, {
        stack: state.stack.filter(function (player) {
          return player.playerId !== payload.playerId;
        })
      });

    case 'SET_STACK_N':
      stackCounts[i] = Number(n);
      return _objectSpread({}, state, {
        stackCounts: stackCounts
      });

    case 'ADD_RESULT':
      return _objectSpread({}, state, {
        results: state.results.concat(payload)
      });

    case 'REMOVE_RESULT':
      var newResults = [];
      var results = state.results,
          stacksUsed = state.stacksUsed;
      var stacksToRemove = [];
      results.forEach(function (result, resultsIndex) {
        if (resultsIndex !== i) {
          return newResults.push([].concat(result));
        }

        var newResult = result.filter(function (r, index) {
          return index !== j;
        });

        if (newResult.length) {
          return newResults.push(newResult);
        }

        stacksToRemove.push(resultsIndex);
      });
      var stacksUsedAfterRemove = stacksUsed.filter(function (s, stacksIndex) {
        return !stackToRemove.includes(stacksIndex);
      });
      return _objectSpread({}, state, {
        results: newResults,
        stacksUsed: stacksUsedAfterRemove
      });

    case 'ADD_PLAYER_TO_POOL':
      return _objectSpread({}, state, {
        pool: state.pool.concat([payload])
      });

    case 'REMOVE_PLAYER_FROM_POOL':
      return _objectSpread({}, state, {
        pool: state.pool.filter(function (player) {
          return player.playerId !== payload.playerId;
        })
      });

    case 'SET_VIEW':
      return _objectSpread({}, state, {
        view: payload
      });

    case 'MOVE_STACK':
      var which = payload.which;
      var stacks = state.stacks.concat([]);
      var stack = stacks[j];

      if (which === "right" && j < stacks.length - 1) {
        var right = stacks[j + 1];
        stacks.splice(j, 1, right);
        stacks.splice(j + 1, 1, stack);
      }

      if (which === "left" && j > 0) {
        var left = stacks[j - 1];
        stacks.splice(j, 1, left);
        stacks.splice(j - 1, 1, stack);
      }

      return _objectSpread({}, state, {
        stacks: stacks,
        stackCounts: stackCounts
      });

    case 'CLEAR_POOL':
      return _objectSpread({}, state, {
        pool: []
      });

    case 'SET_POOL_SALARY_RANGE':
      return _objectSpread({}, state, {
        poolSalaryRange: payload
      });

    case 'TOGGLE_POOL_TOOLS':
      return _objectSpread({}, state, {
        showPoolTools: !state.showPoolTools
      });

    case 'PURGE':
      return state;

    case 'GENERATE':
      var newStacksUsed = !state.generating ? state.stacksUsed.concat(state.stacks) : state.stacksUsed;
      return _objectSpread({}, state, {
        generating: !state.generating,
        stacksUsed: newStacksUsed
      });

    case 'CLEAR_LINEUPS':
      return _objectSpread({}, state, {
        results: []
      });

    default:
      return state;
  }
};

var persistConfig = {
  key: 'primary',
  storage: redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_11___default.a
};
var persistedReducer = Object(redux_persist__WEBPACK_IMPORTED_MODULE_10__["persistReducer"])(persistConfig, reducer);
var initializeStore = function initializeStore() {
  var preloadedState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
  return Object(redux__WEBPACK_IMPORTED_MODULE_8__["createStore"])(persistedReducer, preloadedState, Object(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_9__["composeWithDevTools"])(Object(redux__WEBPACK_IMPORTED_MODULE_8__["applyMiddleware"])()));
};

/***/ })

})
//# sourceMappingURL=index.js.3705c824779546aa68d6.hot-update.js.map