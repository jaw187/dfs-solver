webpackHotUpdate("static/development/pages/index.js",{

/***/ "./components/lineups.js":
/*!*******************************!*\
  !*** ./components/lineups.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./card */ "./components/card.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _solver_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../solver/index */ "./solver/index.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils */ "./components/utils.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_utils__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _generator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./generator */ "./components/generator.js");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/index.js");

var _jsxFileName = "/Users/jwesto1/Code/jaw187/dfs-solver/components/lineups.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;






var solve = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].solve,
    Models = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].Models,
    players = _solver_index__WEBPACK_IMPORTED_MODULE_4__["default"].players;

var getState = function getState() {
  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useDispatch"])();
  var slates = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.slates;
  }, react_redux__WEBPACK_IMPORTED_MODULE_3__["shallowEqual"]);
  var selectedSlate = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.selectedSlate;
  });
  var results = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.results;
  });
  var view = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.view;
  });
  var stacksUsed = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.stacksUsed;
  });
  var projection = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useSelector"])(function (state) {
    return state.projection;
  });

  var removeLineup = function removeLineup(i, j) {
    dispatch({
      type: 'REMOVE_RESULT',
      payload: {
        i: i,
        j: j
      }
    });
  };

  var clearLineups = function clearLineups() {
    dispatch({
      type: 'CLEAR_LINEUPS'
    });
  };

  return {
    slates: slates,
    selectedSlate: selectedSlate,
    results: results,
    view: view,
    removeLineup: removeLineup,
    stacksUsed: stacksUsed,
    clearLineups: clearLineups,
    projection: projection
  };
};

var Lineups = function Lineups() {
  var _getState = getState(),
      slates = _getState.slates,
      selectedSlate = _getState.selectedSlate,
      results = _getState.results,
      view = _getState.view,
      removeLineup = _getState.removeLineup,
      stacksUsed = _getState.stacksUsed,
      clearLineups = _getState.clearLineups,
      projection = _getState.projection;

  if (view !== 'results') {
    return null;
  } // Reorganized results.  Breaking change.


  if (results.length && !(results[0].length >= 0)) {
    return 'Old state observed.  Clear session';
  }

  var slate = slates && slates[selectedSlate];
  var sport = slate && slate.Sport.toLowerCase();
  var site = 'draftkings';
  var type = slate && slate.GameType.Name.toLowerCase();
  var exporters = {
    nfl: {
      draftkings: {
        classic: function classic(result) {
          var _result$lineup = result.lineup,
              qb = _result$lineup.qb,
              rbs = _result$lineup.rbs,
              wrs = _result$lineup.wrs,
              te = _result$lineup.te,
              flex = _result$lineup.flex,
              dst = _result$lineup.dst;
          return "".concat(qb.id, ",").concat(rbs[0].id, ",").concat(rbs[1].id, ",").concat(wrs[0].id, ",").concat(wrs[1].id, ",").concat(wrs[2].id, ",").concat(te.id, ",").concat(flex.id, ",").concat(dst.id);
        }
      }
    },
    golf: {
      draftkings: {
        classic: function classic(result) {
          var g = result.lineup.g;
          return "".concat(g[0].id, ",").concat(g[1].id, ",").concat(g[2].id, ",").concat(g[3].id, ",").concat(g[4].id, ",").concat(g[5].id);
        }
      }
    },
    mma: {
      draftkings: {
        classic: function classic(result) {
          var f = result.lineup.f;
          return "".concat(f[0].id, ",").concat(f[1].id, ",").concat(f[2].id, ",").concat(f[3].id, ",").concat(f[4].id, ",").concat(f[5].id);
        }
      }
    },
    nba: {
      draftkings: {
        classic: function classic(result) {
          var _result$lineup2 = result.lineup,
              pg = _result$lineup2.pg,
              sg = _result$lineup2.sg,
              sf = _result$lineup2.sf,
              pf = _result$lineup2.pf,
              c = _result$lineup2.c,
              g = _result$lineup2.g,
              f = _result$lineup2.f,
              flex = _result$lineup2.flex;
          return "".concat(pg.id, ",").concat(sg.id, ",").concat(sf.id, ",").concat(pf.id, ",").concat(c.id, ",").concat(g.id, ",").concat(f.id, ",").concat(flex.id);
        }
      }
    }
  };

  var generateLineupString = function generateLineupString(lineup) {
    var ids = exporters[sport][site][type](lineup).split(',');
    ids.sort(function (a, b) {
      return a > b ? 1 : -1;
    });
    return ids.join('');
  };

  var playerCounts = {};
  var lineupStrings = [];
  results.forEach(function (stack) {
    stack.forEach(function (result) {
      var lineupString = generateLineupString(result);

      if (!lineupStrings.includes(lineupString)) {
        lineupStrings.push(lineupString);
        result.players.forEach(function (player) {
          if (!playerCounts[player]) {
            playerCounts[player] = 0;
          }

          ++playerCounts[player];
        });
      }
    });
  });

  var formatPlayer = function formatPlayer(_ref) {
    var id = _ref.id;
    var player = slate.players.find(function (player) {
      return player.draftableId == id;
    });

    if (!player) {
      return id;
    }

    var playerProjection = Math.round(projection.filter(function (projectionPlayer) {
      return projectionPlayer.player === id;
    })[0].value);
    return "".concat(player.position, " - ").concat(player.displayName, " - $").concat(player.salary, " - ").concat(playerProjection);
  };

  var headers = {
    nfl: {
      draftkings: {
        classic: "QB,RB,RB,WR,WR,WR,TE,FLEX,DST\n"
      }
    },
    golf: {
      draftkings: {
        classic: "G,G,G,G,G,G\n"
      }
    },
    mma: {
      draftkings: {
        classic: "F,F,F,F,F,F\n"
      }
    },
    nba: {
      draftkings: {
        classic: "PG,SG,SF,PF,C,G,F,UTIL\n"
      }
    }
  };

  var exportToCSV = function exportToCSV() {
    Object(_utils__WEBPACK_IMPORTED_MODULE_5__["log"])('export linieups');
    var header = headers[sport][site][type];
    var lines = [];
    var exportedLines = [];
    results.forEach(function (result) {
      result.forEach(function (line) {
        var lineupString = generateLineupString(line);

        if (!exportedLines.includes(lineupString)) {
          lines.push(line);
          exportedLines.push(lineupString);
        }
      });
    });
    var csv = "data:text/csv;charset=utf-8," + header + lines.map(exporters[sport][site][type]).join('\n');
    var _window = window,
        encodeURI = _window.encodeURI;
    var downloadLink = document.createElement("a");
    downloadLink.href = encodeURI(csv);
    downloadLink.download = "".concat(selectedSlate, " - Lineups.csv");
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  var remove = function remove(i, j) {
    Object(_utils__WEBPACK_IMPORTED_MODULE_5__["log"])('remove lineup');
    return function () {
      return removeLineup(i, j);
    };
  };

  var containerStyle = {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingBottom: 32
  };
  var lineupStyle = {
    padding: 16,
    margin: 8,
    backgroundColor: "#f3f3f3",
    border: '1px solid #DDD',
    fontSize: 12,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center'
  };
  var cardContainer = {
    display: 'flex',
    flexDirection: 'row'
  };
  var componentContainer = {
    padding: 16
  };

  var ownership = _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(playerCounts).map(function (player) {
    return {
      player: formatPlayer({
        id: player
      }),
      count: playerCounts[player],
      percentage: (playerCounts[player] / lineupStrings.length * 100).toFixed(0)
    };
  });

  var ownershipPlayerStyle = {
    whiteSpace: 'nowrap'
  };
  var removeButtonStyle = {
    marginTop: 16
  };
  var lineupFormats = {
    nfl: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 242
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 243
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 244
              },
              __self: this
            }, formatPlayer(result.lineup.qb)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 245
              },
              __self: this
            }, formatPlayer(result.lineup.rbs[0])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 246
              },
              __self: this
            }, formatPlayer(result.lineup.rbs[1])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 247
              },
              __self: this
            }, formatPlayer(result.lineup.wrs[0])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 248
              },
              __self: this
            }, formatPlayer(result.lineup.wrs[1])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 249
              },
              __self: this
            }, formatPlayer(result.lineup.wrs[2])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 250
              },
              __self: this
            }, formatPlayer(result.lineup.te)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 251
              },
              __self: this
            }, formatPlayer(result.lineup.flex)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 252
              },
              __self: this
            }, formatPlayer(result.lineup.dst))), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 254
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    },
    golf: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 264
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 265
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 266
              },
              __self: this
            }, formatPlayer(result.lineup.g[0])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 267
              },
              __self: this
            }, formatPlayer(result.lineup.g[1])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 268
              },
              __self: this
            }, formatPlayer(result.lineup.g[2])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 269
              },
              __self: this
            }, formatPlayer(result.lineup.g[3])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 270
              },
              __self: this
            }, formatPlayer(result.lineup.g[4])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 271
              },
              __self: this
            }, formatPlayer(result.lineup.g[5]))), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 273
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    },
    mma: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 283
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 284
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 285
              },
              __self: this
            }, formatPlayer(result.lineup.f[0])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 286
              },
              __self: this
            }, formatPlayer(result.lineup.f[1])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 287
              },
              __self: this
            }, formatPlayer(result.lineup.f[2])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 288
              },
              __self: this
            }, formatPlayer(result.lineup.f[3])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 289
              },
              __self: this
            }, formatPlayer(result.lineup.f[4])), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 290
              },
              __self: this
            }, formatPlayer(result.lineup.f[5]))), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 292
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    },
    nba: {
      draftkings: {
        classic: function classic(i) {
          return function (result, j) {
            return __jsx("div", {
              key: j,
              style: lineupStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 302
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 303
              },
              __self: this
            }, __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 304
              },
              __self: this
            }, formatPlayer(result.lineup.pg)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 305
              },
              __self: this
            }, formatPlayer(result.lineup.sg)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 306
              },
              __self: this
            }, formatPlayer(result.lineup.sf)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 307
              },
              __self: this
            }, formatPlayer(result.lineup.pf)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 308
              },
              __self: this
            }, formatPlayer(result.lineup.c)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 309
              },
              __self: this
            }, formatPlayer(result.lineup.g)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 310
              },
              __self: this
            }, formatPlayer(result.lineup.f)), __jsx("div", {
              __source: {
                fileName: _jsxFileName,
                lineNumber: 311
              },
              __self: this
            }, formatPlayer(result.lineup.flex))), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClick: remove(i, j),
              variant: "contained",
              color: "secondary",
              size: "small",
              style: removeButtonStyle,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 313
              },
              __self: this
            }, "Remove"));
          };
        }
      }
    }
  };
  var removeAllButtonStyle = {
    marginLeft: 24
  };
  var stackHeaderStyle = {
    marginBottom: 4
  };

  var displayStack = function displayStack(stack, i) {
    return __jsx("div", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 331
      },
      __self: this
    }, __jsx("h5", {
      style: stackHeaderStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 332
      },
      __self: this
    }, stack.map(function (player) {
      return player.displayName;
    }).join(' - ')), __jsx("div", {
      style: containerStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 333
      },
      __self: this
    }, results[i] && results[i].map(lineupFormats[sport][site][type](i))));
  };

  return __jsx("div", {
    style: componentContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 343
    },
    __self: this
  }, __jsx("h2", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 344
    },
    __self: this
  }, "Lineups"), __jsx("div", {
    style: cardContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 345
    },
    __self: this
  }, __jsx(_generator__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 346
    },
    __self: this
  })), results && results.length > 0 && __jsx("div", {
    style: cardContainer,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 349
    },
    __self: this
  }, __jsx(_card__WEBPACK_IMPORTED_MODULE_2__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 350
    },
    __self: this
  }, __jsx("h3", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 351
    },
    __self: this
  }, "Ownership"), !!ownership.length && __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 354
    },
    __self: this
  }, ownership.map(function (data) {
    return __jsx("div", {
      style: ownershipPlayerStyle,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 357
      },
      __self: this
    }, data.player, " - ", data.count, " - ", data.percentage, "%");
  }))), __jsx(_card__WEBPACK_IMPORTED_MODULE_2__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 366
    },
    __self: this
  }, !!results.length && __jsx("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 369
    },
    __self: this
  }, __jsx("h3", {
    style: {
      marginTop: 0
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 370
    },
    __self: this
  }, "Your Lineups"), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
    onClick: exportToCSV,
    variant: "contained",
    color: "primary",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 371
    },
    __self: this
  }, "Export"), __jsx(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_7__["default"], {
    onClick: clearLineups,
    variant: "contained",
    color: "secondary",
    style: removeAllButtonStyle,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 372
    },
    __self: this
  }, "Remove All"), __jsx("h4", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 373
    },
    __self: this
  }, lineupStrings.length, " unique results"), stacksUsed && stacksUsed.map(displayStack)))));
};

/* harmony default export */ __webpack_exports__["default"] = (Lineups);

/***/ })

})
//# sourceMappingURL=index.js.af5ee37eadaa32153049.hot-update.js.map