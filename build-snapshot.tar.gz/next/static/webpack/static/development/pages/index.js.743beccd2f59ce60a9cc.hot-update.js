webpackHotUpdate("static/development/pages/index.js",{

/***/ "./solver/rosters.js":
/*!***************************!*\
  !*** ./solver/rosters.js ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _Object$defineProperty = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");

var _Object$defineProperties = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-properties */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js");

var _Object$getOwnPropertyDescriptors = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptors */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptors.js");

var _Object$getOwnPropertyDescriptor = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptor */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js");

var _Object$getOwnPropertySymbols = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-symbols */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js");

var _Object$keys = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");

var _defineProperty = __webpack_require__(/*! @babel/runtime-corejs2/helpers/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/defineProperty.js");

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

var id = 1;

var createPlayer = function createPlayer(points, salary, ownership, startTime) {
  return {
    points: points,
    pointz: points,
    salary: salary,
    ownership: ownership,
    startTime: startTime,
    player: 1,
    id: ++id
  };
};

module.exports = {
  nfl: {
    draftkings: {
      classic: {
        QB: function QB(points, salary, ownership, startTime) {
          var positions = {
            qb: 1,
            rb: 0,
            wr: 0,
            te: 0,
            dst: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        RB: function RB(points, salary, ownership, startTime) {
          var positions = {
            qb: 0,
            rb: 1,
            wr: 0,
            te: 0,
            dst: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        WR: function WR(points, salary, ownership, startTime) {
          var positions = {
            qb: 0,
            rb: 0,
            wr: 1,
            te: 0,
            dst: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        TE: function TE(points, salary, ownership, startTime) {
          var positions = {
            qb: 0,
            rb: 0,
            wr: 0,
            te: 1,
            dst: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        DST: function DST(points, salary, ownership, startTime) {
          var positions = {
            qb: 0,
            rb: 0,
            wr: 0,
            te: 0,
            dst: 1
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        }
      }
    }
  },
  golf: {
    draftkings: {
      classic: {
        G: function G(points, salary, ownership, startTime) {
          var positions = {
            g: 1
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        }
      }
    }
  },
  mma: {
    draftkings: {
      classic: {
        F: function F(points, salary, ownership, startTime) {
          var positions = {
            f: 1
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        }
      }
    }
  },
  nba: {
    draftkings: {
      classic: {
        PG: function PG(points, salary, ownership, startTime) {
          var positions = {
            pg: 1,
            sg: 0,
            sf: 0,
            pf: 0,
            c: 0,
            g: 1,
            f: 0,
            conly: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        SG: function SG(points, salary, ownership, startTime) {
          var positions = {
            pg: 0,
            sg: 1,
            sf: 0,
            pf: 0,
            c: 0,
            g: 1,
            f: 0,
            conly: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        SF: function SF(points, salary, ownership, startTime) {
          var positions = {
            pg: 0,
            sg: 0,
            sf: 1,
            pf: 0,
            c: 0,
            g: 0,
            f: 1,
            conly: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        PF: function PF(points, salary, ownership, startTime) {
          var positions = {
            pg: 0,
            sg: 0,
            sf: 0,
            pf: 1,
            c: 0,
            g: 0,
            f: 1,
            conly: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        C: function C(points, salary, ownership, startTime) {
          var positions = {
            pg: 0,
            sg: 0,
            sf: 0,
            pf: 0,
            c: 1,
            g: 0,
            f: 0,
            conly: 1
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        }
      }
    }
  },
  xfl: {
    draftkings: {
      classic: {
        QB: function QB(points, salary, ownership, startTime) {
          var positions = {
            qb: 1,
            rb: 0,
            wr: 0,
            dst: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        RB: function RB(points, salary, ownership, startTime) {
          var positions = {
            qb: 0,
            rb: 1,
            wr: 0,
            dst: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        WR: function WR(points, salary, ownership, startTime) {
          var positions = {
            qb: 0,
            rb: 0,
            wr: 1,
            dst: 0
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        },
        DST: function DST(points, salary, ownership, startTime) {
          var positions = {
            qb: 0,
            rb: 0,
            wr: 0,
            dst: 1
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        }
      }
    }
  },
  nas: {
    draftkings: {
      classic: {
        F: function F(points, salary, ownership, startTime) {
          var positions = {
            d: 1
          };
          var player = createPlayer(points, salary, ownership, startTime);
          return _objectSpread({}, player, {}, positions);
        }
      }
    }
  }
};

/***/ })

})
//# sourceMappingURL=index.js.743beccd2f59ce60a9cc.hot-update.js.map