webpackHotUpdate("static/development/pages/index.js",{

/***/ "./solver/models.js":
/*!**************************!*\
  !*** ./solver/models.js ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _Object$keys = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");

var _classCallCheck = __webpack_require__(/*! @babel/runtime-corejs2/helpers/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/classCallCheck.js");

var _createClass = __webpack_require__(/*! @babel/runtime-corejs2/helpers/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/createClass.js");

var clone = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");

var constraintList = {
  nfl: {
    draftkings: {
      classic: {
        pointz: {
          max: 100000
        },
        salary: {
          max: 50000
        },
        qb: {
          min: 1,
          max: 1
        },
        rb: {
          min: 2,
          max: 3
        },
        wr: {
          min: 3,
          max: 4
        },
        te: {
          min: 1,
          max: 2
        },
        dst: {
          min: 1,
          max: 1
        },
        player: {
          equal: 9
        }
      }
    }
  },
  golf: {
    draftkings: {
      classic: {
        pointz: {
          max: 100000
        },
        salary: {
          max: 50000
        },
        g: {
          equal: 6
        }
      }
    }
  },
  mma: {
    draftkings: {
      classic: {
        pointz: {
          max: 100000
        },
        salary: {
          max: 50000
        },
        f: {
          equal: 6
        }
      }
    }
  },
  nba: {
    draftkings: {
      classic: {
        pointz: {
          max: 100000
        },
        salary: {
          max: 50000
        },
        pg: {
          min: 1
        },
        sg: {
          min: 1
        },
        sf: {
          min: 1
        },
        pf: {
          min: 1
        },
        c: {
          min: 1
        },
        g: {
          min: 3
        },
        f: {
          min: 3
        },
        player: {
          equal: 8
        },
        conly: {
          max: 2
        }
      }
    }
  },
  xfl: {
    draftkings: {
      classic: {
        pointz: {
          max: 100000
        },
        salary: {
          max: 50000
        },
        qb: {
          equal: 1
        },
        rb: {
          min: 1
        },
        wr: {
          min: 2
        },
        dst: {
          equal: 1
        },
        player: {
          equal: 9
        }
      }
    }
  },
  nas: {
    draftkings: {
      classic: {
        pointz: {
          max: 100000
        },
        salary: {
          max: 50000
        },
        d: {
          equal: 6
        }
      }
    }
  }
};

var Model =
/*#__PURE__*/
function () {
  "use strict";

  function Model(players, constraints) {
    _classCallCheck(this, Model);

    this.optimize = 'points';
    this.opType = 'max';
    this.constraints = constraints;
    this.variables = players;
    var ints = this.ints = {};

    _Object$keys(players).forEach(function (player) {
      // Limit results so player only shows up once in results.
      // More players results in more complexity
      players[player][player] = 1;
      constraints[player] = {
        max: 1
      };
      ints[player] = 1;
    });
  }

  _createClass(Model, [{
    key: "removePlayer",
    value: function removePlayer(player) {
      var constraints = this.constraints,
          ints = this.ints;
      delete constraints[player];
      delete ints[player];
    }
  }]);

  return Model;
}();

module.exports = {
  nfl: {
    draftkings: {
      classic: function classic(players) {
        return new Model(players, clone(constraintList.nfl.draftkings.classic));
      }
    }
  },
  golf: {
    draftkings: {
      classic: function classic(players) {
        return new Model(players, clone(constraintList.golf.draftkings.classic));
      }
    }
  },
  mma: {
    draftkings: {
      classic: function classic(players) {
        return new Model(players, clone(constraintList.mma.draftkings.classic));
      }
    }
  },
  nba: {
    draftkings: {
      classic: function classic(players) {
        return new Model(players, clone(constraintList.nba.draftkings.classic));
      }
    }
  },
  xfl: {
    draftkings: {
      classic: function classic(players) {
        return new Model(players, clone(constraintList.xfl.draftkings.classic));
      }
    }
  },
  nas: {
    draftkings: {
      classic: function classic(players) {
        return new Model(players, clone(constraintList.nas.draftkings.classic));
      }
    }
  }
};

/***/ })

})
//# sourceMappingURL=index.js.222e919d4cfdc1af8c34.hot-update.js.map