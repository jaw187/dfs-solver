webpackHotUpdate("static/development/pages/index.js",{

/***/ "./solver/solve.worker.js":
/*!********************************!*\
  !*** ./solver/solve.worker.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function () {
  return new Worker("/_next/" + "static/0cbec994b3f9e40abeb4.worker.js");
};

/***/ })

})
//# sourceMappingURL=index.js.6b316eecc6d4b9a8000e.hot-update.js.map