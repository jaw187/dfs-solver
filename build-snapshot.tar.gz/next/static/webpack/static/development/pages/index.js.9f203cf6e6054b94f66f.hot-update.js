webpackHotUpdate("static/development/pages/index.js",{

/***/ "./solver/solve.worker.js":
/*!********************************!*\
  !*** ./solver/solve.worker.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function () {
  return new Worker("/_next/" + "static/f8e245906b2ac3ce4b1e.worker.js");
};

/***/ })

})
//# sourceMappingURL=index.js.9f203cf6e6054b94f66f.hot-update.js.map