webpackHotUpdate("static/development/pages/index.js",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-properties */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptors */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptors.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptor */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-symbols */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_corejs2_core_js_promise__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/promise */ "./node_modules/@babel/runtime-corejs2/core-js/promise.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_promise__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_promise__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/regenerator */ "./node_modules/@babel/runtime-corejs2/regenerator/index.js");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! next/head */ "./node_modules/next/dist/next-server/lib/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_header__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/header */ "./components/header.js");
/* harmony import */ var _components_importprojection_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/importprojection.js */ "./components/importprojection.js");
/* harmony import */ var _components_slatepicker__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../components/slatepicker */ "./components/slatepicker.js");
/* harmony import */ var _components_stackbuilder__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../components/stackbuilder */ "./components/stackbuilder.js");
/* harmony import */ var _components_pool__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../components/pool */ "./components/pool.js");
/* harmony import */ var _components_navigation__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../components/navigation */ "./components/navigation.js");
/* harmony import */ var _components_lineups__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../components/lineups */ "./components/lineups.js");
/* harmony import */ var _lib_redux__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../lib/redux */ "./lib/redux.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! isomorphic-unfetch */ "./node_modules/next/dist/build/polyfills/fetch/index.js");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_21__);










var _jsxFileName = "/Users/jwesto1/Code/jaw187/dfs-solver/pages/index.js";


var __jsx = react__WEBPACK_IMPORTED_MODULE_11___default.a.createElement;

function ownKeys(object, enumerableOnly) { var keys = _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_6___default()(object); if (_babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default.a) { var symbols = _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default()(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default()(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(target, key, source[key]); }); } else if (_babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default.a) { _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1___default()(target, _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default()(source)); } else { ownKeys(Object(source)).forEach(function (key) { _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, key, _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default()(source, key)); }); } } return target; }











var slates = {};
var supportedSports = ['NFL', 'GOLF', 'MMA', 'NBA'];
var supportedGameTypes = ['Classic'];

var getPlayers =
/*#__PURE__*/
function () {
  var _ref = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_9__["default"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_7___default.a.mark(function _callee(slate) {
    var draftGroupId, playersRes, playerIds, rawPlayers, players;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_7___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!(supportedSports.includes(slate.Sport) && slate.GameType && supportedGameTypes.includes(slate.GameType.Name))) {
              _context.next = 13;
              break;
            }

            draftGroupId = slate.DraftGroupId;

            if (slates[draftGroupId]) {
              _context.next = 13;
              break;
            }

            //Handle errrrrsssds
            console.log("http://api.draftkings.com/draftgroups/v1/draftgroups/".concat(draftGroupId, "/draftables?format=json"));
            _context.next = 6;
            return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_21___default()("http://api.draftkings.com/draftgroups/v1/draftgroups/".concat(draftGroupId, "/draftables?format=json"), {
              mode: 'no-cors'
            });

          case 6:
            playersRes = _context.sent;
            playerIds = [];
            _context.next = 10;
            return playersRes.json();

          case 10:
            rawPlayers = _context.sent;
            players = rawPlayers && rawPlayers.draftables && rawPlayers.draftables.filter(function (player) {
              var id = player.playerId;

              if (playerIds.includes(id)) {
                return false;
              }

              playerIds.push(id);
              return true;
            });
            slates[draftGroupId] = _objectSpread({}, slate, {
              players: players
            });

          case 13:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getPlayers(_x) {
    return _ref.apply(this, arguments);
  };
}();

var containerStyle = {
  backgroundColor: '#f6f6f6',
  height: '100%',
  width: '100%'
};
var topBarStyle = {
  backgroundColor: '#ffffff',
  margin: '0px 0px 16px 0px',
  padding: 16,
  display: 'flex',
  flexDirection: 'row',
  boxShadow: '1px 1px 17px -1px hsla(0, 0%, 63%, .69)'
};

var Index = function Index() {
  return __jsx("div", {
    style: containerStyle,
    className: "jsx-2111231969",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    },
    __self: this
  }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_12___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    },
    __self: this
  }, __jsx("meta", {
    name: "viewport",
    content: "width=device-width, initial-scale=1",
    className: "jsx-2111231969",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    },
    __self: this
  }), __jsx("meta", {
    charSet: "utf-8",
    className: "jsx-2111231969",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66
    },
    __self: this
  }), __jsx("link", {
    href: "https://fonts.googleapis.com/css?family=Ubuntu,Ubuntu:400,700&display=swap",
    rel: "stylesheet",
    className: "jsx-2111231969",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67
    },
    __self: this
  })), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_10___default.a, {
    id: "2111231969",
    __self: this
  }, "body{background:#f6f6f6;color:#333;margin:0;padding:0;font-family:'Ubuntu';overflow-x:scroll;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9qd2VzdG8xL0NvZGUvamF3MTg3L2Rmcy1zb2x2ZXIvcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBb0V5QixBQUc4QixtQkFDUixXQUNGLFNBQ0MsVUFDVyxxQkFDSCxrQkFDcEIiLCJmaWxlIjoiL1VzZXJzL2p3ZXN0bzEvQ29kZS9qYXcxODcvZGZzLXNvbHZlci9wYWdlcy9pbmRleC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCc7XG5pbXBvcnQgSGVhZGVyIGZyb20gICcuLi9jb21wb25lbnRzL2hlYWRlcic7XG5pbXBvcnQgSW1wb3J0UHJvamVjdGlvbiBmcm9tICcuLi9jb21wb25lbnRzL2ltcG9ydHByb2plY3Rpb24uanMnO1xuaW1wb3J0IFNsYXRlUGlja2VyIGZyb20gJy4uL2NvbXBvbmVudHMvc2xhdGVwaWNrZXInO1xuaW1wb3J0IFN0YWNrQnVpbGRlciBmcm9tICcuLi9jb21wb25lbnRzL3N0YWNrYnVpbGRlcic7XG5pbXBvcnQgUG9vbCBmcm9tICcuLi9jb21wb25lbnRzL3Bvb2wnO1xuaW1wb3J0IE5hdmlnYXRpb24gZnJvbSAnLi4vY29tcG9uZW50cy9uYXZpZ2F0aW9uJztcbmltcG9ydCBMaW5ldXBzIGZyb20gJy4uL2NvbXBvbmVudHMvbGluZXVwcyc7XG5pbXBvcnQgeyB3aXRoUmVkdXggfSBmcm9tICcuLi9saWIvcmVkdXgnO1xuaW1wb3J0IGZldGNoIGZyb20gJ2lzb21vcnBoaWMtdW5mZXRjaCc7XG5cbmNvbnN0IHNsYXRlcyA9IHt9O1xuXG5jb25zdCBzdXBwb3J0ZWRTcG9ydHMgPSBbJ05GTCcsICdHT0xGJywgJ01NQScsICdOQkEnXTtcbmNvbnN0IHN1cHBvcnRlZEdhbWVUeXBlcyA9IFsnQ2xhc3NpYyddO1xuXG5jb25zdCBnZXRQbGF5ZXJzID0gYXN5bmMgZnVuY3Rpb24gKHNsYXRlKSB7XG4gIGlmIChzdXBwb3J0ZWRTcG9ydHMuaW5jbHVkZXMoc2xhdGUuU3BvcnQpICYmIHNsYXRlLkdhbWVUeXBlICYmIHN1cHBvcnRlZEdhbWVUeXBlcy5pbmNsdWRlcyhzbGF0ZS5HYW1lVHlwZS5OYW1lKSkge1xuICAgIGNvbnN0IGRyYWZ0R3JvdXBJZCA9IHNsYXRlLkRyYWZ0R3JvdXBJZDtcbiAgICBpZiAoIXNsYXRlc1tkcmFmdEdyb3VwSWRdKSB7XG4gICAgICAvL0hhbmRsZSBlcnJycnJzc3Nkc1xuICAgICAgY29uc29sZS5sb2coYGh0dHA6Ly9hcGkuZHJhZnRraW5ncy5jb20vZHJhZnRncm91cHMvdjEvZHJhZnRncm91cHMvJHtkcmFmdEdyb3VwSWR9L2RyYWZ0YWJsZXM/Zm9ybWF0PWpzb25gKVxuICAgICAgY29uc3QgcGxheWVyc1JlcyA9IGF3YWl0IGZldGNoKGBodHRwOi8vYXBpLmRyYWZ0a2luZ3MuY29tL2RyYWZ0Z3JvdXBzL3YxL2RyYWZ0Z3JvdXBzLyR7ZHJhZnRHcm91cElkfS9kcmFmdGFibGVzP2Zvcm1hdD1qc29uYCwgeyBtb2RlOiAnbm8tY29ycycgfSk7XG5cbiAgICAgIGNvbnN0IHBsYXllcklkcyA9IFtdO1xuICAgICAgY29uc3QgcmF3UGxheWVycyA9IGF3YWl0IHBsYXllcnNSZXMuanNvbigpO1xuXG4gICAgICBjb25zdCBwbGF5ZXJzID0gcmF3UGxheWVycyAmJiByYXdQbGF5ZXJzLmRyYWZ0YWJsZXMgJiYgcmF3UGxheWVycy5kcmFmdGFibGVzLmZpbHRlcigocGxheWVyKSA9PiB7XG4gICAgICAgIGNvbnN0IGlkID0gcGxheWVyLnBsYXllcklkO1xuICAgICAgICBpZiAocGxheWVySWRzLmluY2x1ZGVzKGlkKSkge1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHBsYXllcklkcy5wdXNoKGlkKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9KTtcblxuICAgICAgc2xhdGVzW2RyYWZ0R3JvdXBJZF0gPSB7XG4gICAgICAgIC4uLnNsYXRlLFxuICAgICAgICBwbGF5ZXJzXG4gICAgICB9O1xuICAgIH1cbiAgfVxufTtcblxuY29uc3QgY29udGFpbmVyU3R5bGUgPSB7XG4gIGJhY2tncm91bmRDb2xvcjogJyNmNmY2ZjYnLFxuICBoZWlnaHQ6ICcxMDAlJyxcbiAgd2lkdGg6ICcxMDAlJ1xufTtcblxuY29uc3QgdG9wQmFyU3R5bGUgPSB7XG4gIGJhY2tncm91bmRDb2xvcjogJyNmZmZmZmYnLFxuICBtYXJnaW46ICcwcHggMHB4IDE2cHggMHB4JyxcbiAgcGFkZGluZzogMTYsXG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ3JvdycsXG4gIGJveFNoYWRvdzogJzFweCAxcHggMTdweCAtMXB4IGhzbGEoMCwgMCUsIDYzJSwgLjY5KSdcbn1cblxuY29uc3QgSW5kZXggPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17Y29udGFpbmVyU3R5bGV9PlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDxtZXRhIG5hbWU9XCJ2aWV3cG9ydFwiIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MVwiIC8+XG4gICAgICAgIDxtZXRhIGNoYXJTZXQ9XCJ1dGYtOFwiIC8+XG4gICAgICAgIDxsaW5rIGhyZWY9XCJodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9VWJ1bnR1LFVidW50dTo0MDAsNzAwJmRpc3BsYXk9c3dhcFwiIHJlbD1cInN0eWxlc2hlZXRcIj48L2xpbms+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8c3R5bGUganN4IGdsb2JhbD57YFxuICAgICAgICBib2R5IHtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjZmNmY2O1xuICAgICAgICAgIGNvbG9yOiAjMzMzO1xuICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgIGZvbnQtZmFtaWx5OiAnVWJ1bnR1JztcbiAgICAgICAgICBvdmVyZmxvdy14OiBzY3JvbGw7XG4gICAgICAgIH1cbiAgICAgIGB9PC9zdHlsZT5cbiAgICAgIDxkaXYgc3R5bGU9e3RvcEJhclN0eWxlfT5cbiAgICAgICAgPEhlYWRlciAvPlxuICAgICAgICA8TmF2aWdhdGlvbiAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8U2xhdGVQaWNrZXIgLz5cbiAgICAgIDxJbXBvcnRQcm9qZWN0aW9uIC8+XG4gICAgICA8UG9vbCAvPlxuICAgICAgPFN0YWNrQnVpbGRlciAvPlxuICAgICAgPExpbmV1cHMgLz5cbiAgICAgIDxpbWcgc3JjPVwiaHR0cHM6Ly9sb2dzLTAxLmxvZ2dseS5jb20vaW5wdXRzLzhhNDY1OTc4LWFkZDItNGI1OC05ZDU3LTAyZjg4NjliMmYxNy5naWY/c291cmNlPXBpeGVsJmRhdGE9bG9hZFwiIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8vIFRoaXMgaXMgdG8gdHJ5IGFuZCBzdG9wIHNwYW1taW5nIERLXG5sZXQgZmV0Y2hlZCA9IGZhbHNlO1xubGV0IGZldGNoaW5nID0gZmFsc2U7XG5jb25zdCByZWZyZXNoU2xhdGVzUmF0ZSA9IDEwMDAgKiA2MCAqIDYwO1xuY29uc3QgY2xlYXJTbGF0ZXMgPSAoKSA9PiB7XG4gIE9iamVjdC5rZXlzKHNsYXRlcykuZm9yRWFjaCgoc2xhdGUpID0+IHtcbiAgICBkZWxldGUgc2xhdGVzW3NsYXRlXTtcbiAgfSk7XG5cbiAgZmV0Y2hlZCA9IGZhbHNlO1xuICBmZXRjaGluZyA9IGZhbHNlO1xufTtcbnNldEludGVydmFsKGNsZWFyU2xhdGVzLCByZWZyZXNoU2xhdGVzUmF0ZSk7XG5cbkluZGV4LmdldEluaXRpYWxQcm9wcyA9IGFzeW5jICh7IHJlZHV4U3RvcmUgfSkgPT4ge1xuICBpZiAoIWZldGNoZWQgJiYgIWZldGNoaW5nKSB7XG4gICAgZmV0Y2hpbmcgPSB0cnVlO1xuICAgIC8vIEhhbmRsZSBlcnJycnJzXG4gICAgLy8gR2V0IGFsbCBzbGF0ZXNcbiAgICAvLyBOZWVkcyB0byBiZSBpbXByb3ZlZCBzdWNoIHRoYXQgZWFjaCByZXF1ZXN0IGRvZXNuJ3QgdHJpZ2dlciBhbiBvdXRnb2luZyByZXF1ZXN0XG4gICAgY29uc29sZS5sb2coJ2dldHRpbmcgc2xhdGVzJylcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnaHR0cHM6Ly93d3cuZHJhZnRraW5ncy5jb20vbGluZXVwL2dldHVwY29taW5nY29udGVzdGluZm8nLCB7IG1ldGhvZDogJ3Bvc3QnLCBtb2RlOiAnbm8tY29ycycgfSk7XG4gICAgY29uc3QgcmF3U2xhdGVzID0gYXdhaXQgcmVzLmpzb24oKTtcblxuICAgIC8vIEdldCBwbGF5ZXJzIGZyb20gc2xhdGVcbiAgICBhd2FpdCBQcm9taXNlLmFsbChyYXdTbGF0ZXMubWFwKGdldFBsYXllcnMpKTtcbiAgICBmZXRjaGVkID0gdHJ1ZTtcbiAgfVxuXG4gIGNvbnN0IHsgZGlzcGF0Y2ggfSA9IHJlZHV4U3RvcmU7XG4gIGNvbnNvbGUubG9nKCdzZXR0aW5nIHNsYXRlcycpLy8sIHNsYXRlcylcbiAgZGlzcGF0Y2goe1xuICAgIHR5cGU6ICdTRVRfU0xBVEVTJyxcbiAgICBwYXlsb2FkOiBzbGF0ZXNcbiAgfSk7XG5cbiAgcmV0dXJuIHt9O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgd2l0aFJlZHV4KEluZGV4KTtcbiJdfQ== */\n/*@ sourceURL=/Users/jwesto1/Code/jaw187/dfs-solver/pages/index.js */"), __jsx("div", {
    style: topBarStyle,
    className: "jsx-2111231969",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 79
    },
    __self: this
  }, __jsx(_components_header__WEBPACK_IMPORTED_MODULE_13__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 80
    },
    __self: this
  }), __jsx(_components_navigation__WEBPACK_IMPORTED_MODULE_18__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 81
    },
    __self: this
  })), __jsx(_components_slatepicker__WEBPACK_IMPORTED_MODULE_15__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    },
    __self: this
  }), __jsx(_components_importprojection_js__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 84
    },
    __self: this
  }), __jsx(_components_pool__WEBPACK_IMPORTED_MODULE_17__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 85
    },
    __self: this
  }), __jsx(_components_stackbuilder__WEBPACK_IMPORTED_MODULE_16__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    },
    __self: this
  }), __jsx(_components_lineups__WEBPACK_IMPORTED_MODULE_19__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 87
    },
    __self: this
  }), __jsx("img", {
    src: "https://logs-01.loggly.com/inputs/8a465978-add2-4b58-9d57-02f8869b2f17.gif?source=pixel&data=load",
    className: "jsx-2111231969",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 88
    },
    __self: this
  }));
}; // This is to try and stop spamming DK


var fetched = false;
var fetching = false;
var refreshSlatesRate = 1000 * 60 * 60;

var clearSlates = function clearSlates() {
  _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_6___default()(slates).forEach(function (slate) {
    delete slates[slate];
  });

  fetched = false;
  fetching = false;
};

setInterval(clearSlates, refreshSlatesRate);

Index.getInitialProps =
/*#__PURE__*/
function () {
  var _ref3 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_9__["default"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_7___default.a.mark(function _callee2(_ref2) {
    var reduxStore, res, rawSlates, dispatch;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_7___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            reduxStore = _ref2.reduxStore;

            if (!(!fetched && !fetching)) {
              _context2.next = 13;
              break;
            }

            fetching = true; // Handle errrrrs
            // Get all slates
            // Needs to be improved such that each request doesn't trigger an outgoing request

            console.log('getting slates');
            _context2.next = 6;
            return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_21___default()('https://www.draftkings.com/lineup/getupcomingcontestinfo', {
              method: 'post',
              mode: 'no-cors'
            });

          case 6:
            res = _context2.sent;
            _context2.next = 9;
            return res.json();

          case 9:
            rawSlates = _context2.sent;
            _context2.next = 12;
            return _babel_runtime_corejs2_core_js_promise__WEBPACK_IMPORTED_MODULE_5___default.a.all(rawSlates.map(getPlayers));

          case 12:
            fetched = true;

          case 13:
            dispatch = reduxStore.dispatch;
            console.log('setting slates'); //, slates)

            dispatch({
              type: 'SET_SLATES',
              payload: slates
            });
            return _context2.abrupt("return", {});

          case 17:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function (_x2) {
    return _ref3.apply(this, arguments);
  };
}();

/* harmony default export */ __webpack_exports__["default"] = (Object(_lib_redux__WEBPACK_IMPORTED_MODULE_20__["withRedux"])(Index));

/***/ })

})
//# sourceMappingURL=index.js.2a49ab16727f8307dcc7.hot-update.js.map