webpackHotUpdate("static/development/pages/index.js",{

/***/ "./solver/solve.worker.js":
/*!********************************!*\
  !*** ./solver/solve.worker.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function () {
  return new Worker("/_next/" + "static/32750612c5e3af78c3c7.worker.js");
};

/***/ })

})
//# sourceMappingURL=index.js.7a4e928a30b6eb9704bd.hot-update.js.map