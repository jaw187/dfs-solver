window["webpackHotUpdate"]("main",{

/***/ "./solver/solve.worker.js":
/*!********************************!*\
  !*** ./solver/solve.worker.js ***!
  \********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _queue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./queue */ "./solver/queue.js");
/* harmony import */ var _ownership__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ownership */ "./solver/ownership.js");
/* harmony import */ var _ownership__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ownership__WEBPACK_IMPORTED_MODULE_1__);



const lineupStrings = [];
let ownership = null;

self.addEventListener('message', (event) => {
  const { data: { action } } = event;
  if (action === 'ownership') {
    const { data: { options } } = event;
    ownership = new _ownership__WEBPACK_IMPORTED_MODULE_1___default.a({ ...options, lineupStrings });
  }

  if (action === 'enqueue') {
    const { data: { n, maxIterations, model, players, sport, site, type, stack, preventMmaFightersInSameFight } } = event;
    _queue__WEBPACK_IMPORTED_MODULE_0__["default"].register(n, maxIterations, model, ownership, players, sport, site, type, stack, preventMmaFightersInSameFight);
  }

  if (action === 'solve') {
    const results = _queue__WEBPACK_IMPORTED_MODULE_0__["default"].go();
    self.postMessage(results);
  }
});


/***/ })

})
//# sourceMappingURL=main.7395be84ea12842ded72.hot-update.js.map