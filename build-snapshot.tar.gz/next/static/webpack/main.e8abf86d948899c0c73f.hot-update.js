window["webpackHotUpdate"]("main",{

/***/ "./solver/formaters.js":
/*!*****************************!*\
  !*** ./solver/formaters.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _Object$keys = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");

module.exports = {
  nfl: {
    draftkings: {
      classic: function classic(players) {
        return function (solution) {
          var points = solution.result;
          var roster = {
            positions: {
              qb: [],
              rb: [],
              wr: [],
              te: [],
              dst: []
            }
          };

          var resultPlayers = _Object$keys(solution).filter(function (key) {
            var keysToRemove = ['feasible', 'result', 'bounded', 'isIntegral'];
            return !keysToRemove.includes(key);
          }); // Add players to positions their eligible for


          var playersEligibleAtMoreThanOnePosition = [];
          resultPlayers.forEach(function (playerId) {
            var positions = 0;
            var player = players[playerId];
            player.id = playerId;

            if (player.qb) {
              ++positions;
              roster.positions.qb.push(player);
            }

            if (player.dst) {
              ++positions;
              roster.positions.dst.push(player);
            }

            if (player.rb) {
              ++positions;
              roster.positions.rb.push(player);
            }

            if (player.wr) {
              ++positions;
              roster.positions.wr.push(player);
            }

            if (player.te) {
              ++positions;
              roster.positions.te.push(player);
            }

            var playsMultiplePositions = positions > 1;

            if (playsMultiplePositions) {
              player.multiplePositions = true;
              playersEligibleAtMoreThanOnePosition.push(player);
            }
          }); // Determine expected position of player.

          playersEligibleAtMoreThanOnePosition.forEach(function (player) {
            var removePlayer = function removePlayer(positionPlayer) {
              return !(player.id === positionPlayer.id);
            };

            if (player.qb && roster.positions.qb.length === 1) {
              roster.positions.rb = roster.positions.rb.filter(removePlayer);
              roster.positions.wr = roster.positions.wr.filter(removePlayer);
              roster.positions.te = roster.positions.te.filter(removePlayer);
              roster.positions.dst = roster.positions.dst.filter(removePlayer);
              return null;
            }

            if (player.rb && roster.positions.rb.length === 2) {
              roster.positions.qb = roster.positions.qb.filter(removePlayer);
              roster.positions.wr = roster.positions.wr.filter(removePlayer);
              roster.positions.te = roster.positions.te.filter(removePlayer);
              roster.positions.dst = roster.positions.dst.filter(removePlayer);
              return null;
            }

            if (player.wr && roster.positions.wr.length === 3) {
              roster.positions.qb = roster.positions.qb.filter(removePlayer);
              roster.positions.rb = roster.positions.rb.filter(removePlayer);
              roster.positions.te = roster.positions.te.filter(removePlayer);
              roster.positions.dst = roster.positions.dst.filter(removePlayer);
              return null;
            }

            if (player.te && roster.positions.te.length === 1) {
              roster.positions.qb = roster.positions.qb.filter(removePlayer);
              roster.positions.rb = roster.positions.rb.filter(removePlayer);
              roster.positions.wr = roster.positions.wr.filter(removePlayer);
              roster.positions.dst = roster.positions.dst.filter(removePlayer);
              return null;
            }

            if (player.dst && roster.positions.dst.length === 1) {
              roster.positions.qb = roster.positions.qb.filter(removePlayer);
              roster.positions.rb = roster.positions.rb.filter(removePlayer);
              roster.positions.wr = roster.positions.wr.filter(removePlayer);
              roster.positions.te = roster.positions.te.filter(removePlayer);
            }
          }); // Sort by start time
          // Attempting to account for late swap

          var sort = function sort(a, b) {
            return a.startTime - b.startTime;
          };

          roster.positions.rb.sort(sort);
          roster.positions.wr.sort(sort);
          roster.positions.te.sort(sort); //construct lineup

          var lineup = {
            qb: roster.positions.qb[0],
            rbs: roster.positions.rb.slice(0, 2),
            wrs: roster.positions.wr.slice(0, 3),
            te: roster.positions.te[0],
            flex: roster.positions.rb[2] || roster.positions.wr[3] || roster.positions.te[1],
            dst: roster.positions.dst[0]
          };
          return {
            points: points,
            lineup: lineup,
            players: resultPlayers
          };
        };
      }
    }
  },
  golf: {
    draftkings: {
      classic: function classic(players) {
        return function (solution) {
          var points = solution.result;
          var roster = {
            positions: {
              g: []
            }
          };

          var resultPlayers = _Object$keys(solution).filter(function (key) {
            var keysToRemove = ['feasible', 'result', 'bounded', 'isIntegral'];
            return !keysToRemove.includes(key);
          }); // Add players to positions their eligible for


          resultPlayers.forEach(function (playerId) {
            var player = players[playerId];
            player.id = playerId;
            roster.positions.g.push(player);
          }); // Sort by start time
          // Attempting to account for late swap

          var sort = function sort(a, b) {
            return a.startTime - b.startTime;
          };

          roster.positions.g.sort(sort); //construct lineup

          var lineup = {
            g: roster.positions.g
          };
          return {
            points: points,
            lineup: lineup,
            players: resultPlayers
          };
        };
      }
    }
  },
  mma: {
    draftkings: {
      classic: function classic(players) {
        return function (solution) {
          var points = solution.result;
          var roster = {
            positions: {
              f: []
            }
          };

          var resultPlayers = _Object$keys(solution).filter(function (key) {
            var keysToRemove = ['feasible', 'result', 'bounded', 'isIntegral'];
            return !keysToRemove.includes(key);
          }); // Add players to positions their eligible for


          resultPlayers.forEach(function (playerId) {
            var player = players[playerId];
            player.id = playerId;
            roster.positions.f.push(player);
          }); // Sort by start time
          // Attempting to account for late swap

          var sort = function sort(a, b) {
            return a.startTime - b.startTime;
          };

          roster.positions.f.sort(sort); //construct lineup

          var lineup = {
            f: roster.positions.f
          };
          return {
            points: points,
            lineup: lineup,
            players: resultPlayers
          };
        };
      }
    }
  },
  nba: {
    draftkings: {
      classic: function classic(players) {
        return function (solution) {
          var points = solution.result;
          var roster = {
            positions: {
              pg: [],
              sg: [],
              sf: [],
              pf: [],
              c: [],
              g: [],
              f: []
            }
          };

          var resultPlayers = _Object$keys(solution).filter(function (key) {
            var keysToRemove = ['feasible', 'result', 'bounded', 'isIntegral'];
            return !keysToRemove.includes(key);
          }); // Add players to positions their eligible for


          var playersEligibleAtMoreThanOnePosition = [];
          resultPlayers.forEach(function (playerId) {
            var positions = 0;
            var player = players[playerId];
            player.id = playerId;

            if (player.pg) {
              ++positions;
              roster.positions.pg.push(player);
            }

            if (player.sg) {
              ++positions;
              roster.positions.sg.push(player);
            }

            if (player.sf) {
              ++positions;
              roster.positions.sf.push(player);
            }

            if (player.pf) {
              ++positions;
              roster.positions.pf.push(player);
            }

            if (player.c) {
              ++positions;
              roster.positions.c.push(player);
            }

            if (player.g) {
              roster.positions.g.push(player);
            }

            if (player.f) {
              roster.positions.f.push(player);
            }

            var playsMultiplePositions = positions > 1;

            if (playsMultiplePositions) {
              playersEligibleAtMoreThanOnePosition.push(player);
            }
          });

          var removePlayerFromOtherPositions = function removePlayerFromOtherPositions(player, positionToIgnore) {
            _Object$keys(roster.positions).forEach(function (key) {
              if (key !== positionToIgnore) {
                var removePlayer = function removePlayer(positionPlayer) {
                  return !(player.id === positionPlayer.id);
                };

                roster.positions[key] = roster.positions[key].filter(removePlayer);
              }
            });
          }; // Sort by start time
          // Attempting to account for late swap


          var sort = function sort(a, b) {
            return a.startTime - b.startTime;
          };

          _Object$keys(roster.positions).forEach(function (key) {
            return roster.positions[key].sort(sort);
          }); // Fill out lineup


          var lineup = {};
          var lineupPositions = ['pg', 'sg', 'sf', 'pf', 'c', 'g', 'f'];
          lineupPositions.sort(function (a, b) {
            return roster.positions[a].length - roster.positions[b].length;
          });
          lineupPositions.forEach(function (position) {
            lineup[position] = roster.positions[position].shift();
            removePlayerFromOtherPositions(lineup[position]);
          });
          lineup.flex = roster.positions.pg[0] || roster.positions.sg[0] || roster.positions.pf[0] || roster.positions.sf[0] || roster.positions.c[0];
          return {
            points: points,
            lineup: lineup,
            players: resultPlayers
          };
        };
      }
    }
  },
  xfl: {
    draftkings: {
      classic: function classic(players) {
        return function (solution) {
          var points = solution.result;
          var roster = {
            positions: {
              qb: [],
              rb: [],
              wr: [],
              dst: []
            }
          };

          var resultPlayers = _Object$keys(solution).filter(function (key) {
            var keysToRemove = ['feasible', 'result', 'bounded', 'isIntegral'];
            return !keysToRemove.includes(key);
          }); // Add players to positions their eligible for


          var playersEligibleAtMoreThanOnePosition = [];
          resultPlayers.forEach(function (playerId) {
            var positions = 0;
            var player = players[playerId];
            player.id = playerId;

            if (player.qb) {
              ++positions;
              roster.positions.qb.push(player);
            }

            if (player.dst) {
              ++positions;
              roster.positions.dst.push(player);
            }

            if (player.rb) {
              ++positions;
              roster.positions.rb.push(player);
            }

            if (player.wr) {
              ++positions;
              roster.positions.wr.push(player);
            }

            var playsMultiplePositions = positions > 1;

            if (playsMultiplePositions) {
              player.multiplePositions = true;
              playersEligibleAtMoreThanOnePosition.push(player);
            }
          }); // Determine expected position of player.

          playersEligibleAtMoreThanOnePosition.forEach(function (player) {
            var removePlayer = function removePlayer(positionPlayer) {
              return !(player.id === positionPlayer.id);
            };

            if (player.qb && roster.positions.qb.length === 1) {
              roster.positions.rb = roster.positions.rb.filter(removePlayer);
              roster.positions.wr = roster.positions.wr.filter(removePlayer);
              roster.positions.dst = roster.positions.dst.filter(removePlayer);
              return null;
            }

            if (player.rb && roster.positions.rb.length === 1) {
              roster.positions.qb = roster.positions.qb.filter(removePlayer);
              roster.positions.wr = roster.positions.wr.filter(removePlayer);
              roster.positions.dst = roster.positions.dst.filter(removePlayer);
              return null;
            }

            if (player.wr && roster.positions.wr.length === 2) {
              roster.positions.qb = roster.positions.qb.filter(removePlayer);
              roster.positions.rb = roster.positions.rb.filter(removePlayer);
              roster.positions.dst = roster.positions.dst.filter(removePlayer);
              return null;
            }

            if (player.dst && roster.positions.dst.length === 1) {
              roster.positions.qb = roster.positions.qb.filter(removePlayer);
              roster.positions.rb = roster.positions.rb.filter(removePlayer);
              roster.positions.wr = roster.positions.wr.filter(removePlayer);
            }
          }); // Sort by start time
          // Attempting to account for late swap

          var sort = function sort(a, b) {
            return a.startTime - b.startTime;
          };

          roster.positions.rb.sort(sort);
          roster.positions.wr.sort(sort); // Assuming only RB and WRs will have dual eligibility.  This league could end up with a QB eligible at another position too

          var flexes = roster.positions.rb.slice(1, roster.positions.rb.length);
          roster.positions.wr.slice(2, roster.positions.wr.length).forEach(function (player) {
            if (!flexes.find(function (a) {
              return a.id === player.id;
            })) {
              flexes.push(player);
            }
          }); //construct lineup

          var lineup = {
            qb: roster.positions.qb[0],
            rb: roster.positions.rb[0],
            wrs: roster.positions.wr.slice(0, 2),
            flexes: flexes,
            dst: roster.positions.dst[0]
          };
          return {
            points: points,
            lineup: lineup,
            players: resultPlayers
          };
        };
      }
    }
  },
  nas: {
    draftkings: {
      classic: function classic(players) {
        return function (solution) {
          var points = solution.result;
          var roster = {
            positions: {
              d: []
            }
          };

          var resultPlayers = _Object$keys(solution).filter(function (key) {
            var keysToRemove = ['feasible', 'result', 'bounded', 'isIntegral'];
            return !keysToRemove.includes(key);
          }); // Add players to positions their eligible for


          resultPlayers.forEach(function (playerId) {
            var player = players[playerId];
            player.id = playerId;
            roster.positions.d.push(player);
          }); // Sort by start time
          // Attempting to account for late swap

          var sort = function sort(a, b) {
            return a.startTime - b.startTime;
          };

          roster.positions.d.sort(sort); //construct lineup

          var lineup = {
            d: roster.positions.d
          };
          return {
            points: points,
            lineup: lineup,
            players: resultPlayers
          };
        };
      }
    }
  }
};

/***/ })

})
//# sourceMappingURL=main.e8abf86d948899c0c73f.hot-update.js.map