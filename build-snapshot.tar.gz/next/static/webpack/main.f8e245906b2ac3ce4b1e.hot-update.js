window["webpackHotUpdate"]("main",{

/***/ "./solver/solver.js":
/*!**************************!*\
  !*** ./solver/solver.js ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var solver = __webpack_require__(/*! javascript-lp-solver */ "./node_modules/javascript-lp-solver/src/main.js");

var formaters = __webpack_require__(/*! ./formaters */ "./solver/formaters.js");

module.exports.solve = function (n, maxIterations, model, ownership, players, sport, site, type, stack, preventMmaFightersInSameFight) {
  var format = formaters[sport][site][type](players);
  var results = [];

  if (sport = 'mma') {}

  var i = 0;

  var go = function go() {
    ++i;
    var solution = solver.Solve(model);
    console.log("Iteration ".concat(i, " is ").concat(solution.feasible ? '' : 'not', " feasible"));
    console.log('ownership - solver', ownership);

    if (!solution.feasible) {
      return {
        notFeasible: true
      };
    } // Prevents finding solutions which have the same total points


    model.constraints.pointz.max = solution.result - 1;

    try {
      var result = format(solution); // Test if lineup is allowed as per ownership

      if (!ownership.validate(result.players)) {
        return {};
      }

      ownership.update(result.players);
      results.push(result);
      return {};
    } catch (e) {
      return {};
    }
  };

  var isDone = function isDone() {
    return i === maxIterations || results.length === n;
  };

  return {
    go: go,
    isDone: isDone,
    results: results,
    stack: stack
  };
};

/***/ })

})
//# sourceMappingURL=main.f8e245906b2ac3ce4b1e.hot-update.js.map